"""
CS 지식 데이터 로드 스크립트

CSV 파일에서 CS 지식 데이터를 ChromaDB에 로드하는 명령행 스크립트
"""

import asyncio
import argparse
import logging
import os
from dotenv import load_dotenv
from app.services.vector_store import VectorStoreService
from app.services.data_loader import load_cs_data_from_csv

# 환경 변수 로드
load_dotenv()

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

async def main():
    """메인 함수"""
    # 명령행 인자 파싱
    parser = argparse.ArgumentParser(description='CS 지식 데이터 로드 스크립트')
    parser.add_argument('--csv', required=True, help='CSV 파일 경로')
    args = parser.parse_args()
    
    # CSV 파일 경로 확인
    if not os.path.exists(args.csv):
        logger.error(f"CSV 파일을 찾을 수 없습니다: {args.csv}")
        return
    
    # 벡터 저장소 서비스 초기화
    try:
        vector_store = VectorStoreService()
        await vector_store.initialize_collection()
        
        # CSV 데이터 로드
        logger.info(f"'{args.csv}' 파일에서 CS 지식 데이터를 로드합니다...")
        doc_count = await load_cs_data_from_csv(args.csv, vector_store)
        
        if doc_count > 0:
            logger.info(f"성공: {doc_count}개 CS 문서가 ChromaDB에 저장되었습니다.")
        else:
            logger.error("실패: CS 데이터 로드 중 오류가 발생했습니다.")
            
    except Exception as e:
        logger.error(f"오류 발생: {e}")

if __name__ == "__main__":
    asyncio.run(main())
