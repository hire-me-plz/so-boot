"""
리허설 평가 서비스

면접 리허설 답변을 평가하고 피드백을 생성하는 RAG 서비스
"""

import os
import json
import logging
from typing import List, Dict, Any, Optional, Tuple
import requests
from datetime import datetime
import statistics

from .vector_store import VectorStoreService, create_db_pool

# 로깅 설정
logger = logging.getLogger(__name__)

class RehearsalService:
    """리허설 서비스"""

    def __init__(self, vector_store_service: Optional[VectorStoreService] = None):
        """
        리허설 서비스 초기화

        Args:
            vector_store_service: 벡터 저장소 서비스 인스턴스 (없을 경우 내부 생성)
        """
        # 벡터 저장소 서비스 설정
        self.vector_store_service = vector_store_service

        # OpenAI API 키 설정
        self.openai_api_key = os.getenv("OPENAI_API_KEY")
        if not self.openai_api_key:
            raise ValueError("OpenAI API 키가 필요합니다. 환경 변수에 OPENAI_API_KEY를 설정해주세요.")

        # OpenAI API 설정 - GMS URL로 수정
        self.api_endpoint = "https://gms.p.ssafy.io/gmsapi/api.openai.com/v1/chat/completions"
        self.api_headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.openai_api_key}"
        }
    
    async def evaluate_rehearsal(self,
                              member_id: int,
                              title: str,
                              questions: List[Dict[str, str]],
                              position: Optional[str] = None) -> Tuple[Dict[str, Any], Optional[int]]:
        """
        면접 리허설 답변 평가
        
        Args:
            member_id: 회원 ID
            title: 리허설 제목
            questions: 질문과 답변 목록
            position: 직무 이름 (옵션)
            
        Returns:
            평가 결과, DB에 저장된 리허설 ID
        """
        try:
            # 각 질문에 대한 피드백 생성
            question_feedbacks = []
            
            for question_data in questions:
                question = question_data["question"]
                answer = question_data["answer"]
                
                # RAG를 통한 기술 지식 검색
                relevant_info = await self._retrieve_relevant_knowledge(question, position)
                
                # 평가 및 피드백 생성
                feedback = await self._generate_feedback(question, answer, relevant_info, position)
                
                if feedback:
                    question_feedbacks.append(feedback)
            
            # 평균 점수 계산
            if question_feedbacks:
                total_score = self._calculate_average_score(question_feedbacks)
            else:
                total_score = 0
            
            # DB에 저장
            rehearsal_id = await self._save_rehearsal_to_db(member_id, title, question_feedbacks, total_score)
               await self._add_or_update_today_streak(member_id=member_id,streak_type=STREAK_TYPE_INTERVIEW)

            # 결과 구성
            result = {
                "rehearsal_result_id": rehearsal_id,
                "member_id": member_id,
                "title": title,
                "total_score": total_score,
                "created_at": datetime.now().isoformat(),
                "question_feedbacks": question_feedbacks
            }
            
            return result, rehearsal_id
        
        except Exception as e:
            logger.error(f"리허설 평가 오류: {e}")
            raise
    
    async def _retrieve_relevant_knowledge(self, question: str, position: Optional[str] = None) -> str:
        """질문에 관련된 지식 검색"""
        try:
            if not self.vector_store_service:
                return ""
            
            # 검색 쿼리 구성
            query = f"{question} {position or ''}"
            
            # 벡터 저장소에서 관련 정보 검색
            results = await self.vector_store_service.query_similar_documents(
                query_text=query,
                filters={"type": "cs_knowledge"},  # CS 지식 필터링
                n_results=3
            )
            
            # 검색 결과가 없는 경우
            if not results["documents"][0]:
                return ""
            
            # 검색된 관련 정보 결합
            relevant_info = "\n\n".join([
                f"참고 자료 {i+1}: {doc}"
                for i, doc in enumerate(results["documents"][0])
            ])
            
            return relevant_info
            
        except Exception as e:
            logger.warning(f"관련 지식 검색 오류 (무시됨): {e}")
            return ""
    
    async def _generate_feedback(self,
                             question: str,
                             answer: str,
                             relevant_info: str,
                             position: Optional[str] = None) -> Dict[str, Any]:
        """
        답변에 대한 평가 및 피드백 생성
        
        Args:
            question: 면접 질문
            answer: 지원자 답변
            relevant_info: 관련 지식 정보
            position: 직무 이름
            
        Returns:
            생성된 피드백 정보
        """
        try:
            # 프롬프트 구성
            position_context = f"{position} 직무" if position else "해당 직무"
            
            # 관련 지식이 있을 경우 추가
            knowledge_context = f"\n\n**관련 참고 자료:**\n{relevant_info}" if relevant_info else ""
            
            prompt = f"""
            당신은 경험 많은 기술 면접관입니다. 다음 면접 질문과 답변을 평가해주세요.
            
            **질문:** {question}
            
            **지원자 답변:** {answer}
            {knowledge_context}
            
            다음 3가지 관점에서 답변을 평가하고 점수를 매겨주세요:
            1. 내용 적합성 (0-100): 질문에 대한 답변이 얼마나 적절한지
            2. 전문성 (0-100): 기술적 지식의 깊이와 정확성
            3. 직무 적합성 (0-100): {position_context}에 필요한 역량을 얼마나 보여주는지
            
            그리고 최종 질문 점수(0-100)를 계산해주세요. 또한 모범 답안을 작성해주세요.
            
            자세한 피드백도 함께 제공해주세요. 잘한 점과 개선할 점을 구체적으로 언급해주세요.
            
            응답은 다음 형식의 JSON으로 제공해주세요:
            {{
                "feedback_text": "상세 피드백 내용",
                "model_answer": "모범 답안",
                "content_relevance_score": 점수(0-100),
                "expertise_score": 점수(0-100),
                "job_fit_score": 점수(0-100),
                "question_score": 점수(0-100)
            }}
            """
            
            # API 요청 데이터
            data = {
                "model": "gpt-4o",  # 또는 "gpt-3.5-turbo"
                "messages": [
                    {"role": "system", "content": "당신은 전문 기술 면접관입니다."},
                    {"role": "user", "content": prompt}
                ],
                "temperature": 0.3
            }
            
            # OpenAI API 호출
            logger.info(f"OpenAI API 호출: 면접 답변 평가")
            response = requests.post(self.api_endpoint, headers=self.api_headers, json=data)
            response.raise_for_status()  # 오류 발생 시 예외 발생
            
            response_data = response.json()
            
            # 응답 파싱
            content = response_data['choices'][0]['message']['content']
            
            # JSON 파싱
            if '```json' in content:
                json_content = content.split('```json')[1].split('```')[0].strip()
                feedback_data = json.loads(json_content)
            elif '```' in content:
                json_content = content.split('```')[1].split('```')[0].strip()
                feedback_data = json.loads(json_content)
            else:
                feedback_data = json.loads(content)
            
            # 평가 결과 구성
            result = {
                "question": question,
                "answer": answer,
                "model_answer": feedback_data["model_answer"],
                "feedback_text": feedback_data["feedback_text"],
                "content_relevance_score": feedback_data["content_relevance_score"],
                "expertise_score": feedback_data["expertise_score"],
                "job_fit_score": feedback_data["job_fit_score"],
                "question_score": feedback_data["question_score"]
            }
            
            return result
            
        except Exception as e:
            logger.error(f"피드백 생성 오류: {e}")
            # 오류 발생 시 기본 피드백 생성
            return {
                "question": question,
                "answer": answer,
                "model_answer": "평가 중 오류가 발생했습니다.",
                "feedback_text": f"답변 평가 중 오류가 발생했습니다: {str(e)}",
                "content_relevance_score": 0,
                "expertise_score": 0,
                "job_fit_score": 0,
                "question_score": 0
            }
    
    def _calculate_average_score(self, question_feedbacks: List[Dict[str, Any]]) -> int:
        """
        전체 평가 점수 계산 (모든 질문 점수의 평균)
        
        Args:
            question_feedbacks: 질문 피드백 목록
            
        Returns:
            평균 점수
        """
        if not question_feedbacks:
            return 0
        
        # 각 질문의 question_score 추출
        scores = [feedback["question_score"] for feedback in question_feedbacks]
        
        # 평균 계산 및 반올림
        average_score = round(statistics.mean(scores))
        
        return average_score
    
    
    async def _save_rehearsal_to_db(self,
                                member_id: int,
                                title: str,
                                question_feedbacks: List[Dict[str, Any]],
                                total_score: int) -> int:
        """
        리허설 결과를 DB에 저장

        Args:
            member_id: 회원 ID
            title: 리허설 제목
            question_feedbacks: 질문 피드백 목록
            total_score: 전체 평가 점수
            
        Returns:
            저장된 리허설 결과 ID
        """
        try:
            # DB 연결 풀에서 연결 가져오기
            pool = create_db_pool()
            conn = pool.get_connection()
            cursor = conn.cursor()

            # 현재 시간 설정
            current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            # 트랜잭션 시작
            conn.start_transaction()

            try:
                # 1. rehearsal_result 테이블에 저장
                result_query = """
                INSERT INTO rehearsal_result (member_id, total_score, title, created_at, updated_at)
                VALUES (%s, %s, %s, %s, %s)
                """
                cursor.execute(result_query, (member_id, total_score, title, current_time, current_time))
                
                # 생성된 rehearsal_result_id 가져오기
                rehearsal_result_id = cursor.lastrowid
                
                # 2. 각 question_feedback 저장
                for feedback in question_feedbacks:
                    feedback_query = """
                    INSERT INTO question_feedback (
                        rehearsal_result_id, question, answer, model_answer, 
                        feedback_text, content_relevance_score, expertise_score, 
                        job_fit_score, question_score, created_at, updated_at
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """
                    cursor.execute(feedback_query, (
                        rehearsal_result_id,
                        feedback["question"],
                        feedback["answer"],
                        feedback["model_answer"],
                        feedback["feedback_text"],
                        feedback["content_relevance_score"],
                        feedback["expertise_score"],
                        feedback["job_fit_score"],
                        feedback["question_score"],
                        current_time,
                        current_time
                    ))
                
                # 트랜잭션 커밋
                conn.commit()
                
                logger.info(f"리허설 결과 (ID: {rehearsal_result_id}) DB 저장 완료")
                return rehearsal_result_id
                
            except Exception as e:
                # 오류 발생 시 롤백
                conn.rollback()
                logger.error(f"DB 저장 중 오류 발생: {e}")
                raise
                
            finally:
                # 연결 종료
                cursor.close()
                conn.close()
                
        except Exception as e:
            logger.error(f"리허설 결과 DB 저장 오류: {e}")
            raise

    def _add_or_update_today_streak(self, member_id: int, streak_type: str):
    try:
        pool = create_db_pool()
        conn = pool.get_connection()
        cursor = conn.cursor()

        today = date.today()
        now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        conn.start_transaction()

        try:
            # 오늘자 동일 streakType 있는지 확인
            select_sql = """
            SELECT id, streak_cnt FROM streak
            WHERE member_id = %s AND streak_type = %s AND DATE(created_at) = %s
            """
            cursor.execute(select_sql, (member_id, streak_type, today))
            result = cursor.fetchone()

            if result:
                streak_id, current_cnt = result
                update_sql = """
                UPDATE streak SET streak_cnt = %s, updated_at = %s WHERE id = %s
                """
                cursor.execute(update_sql, (current_cnt + 1, now_str, streak_id))
                logger.info(f"Streak {streak_id} 업데이트: {current_cnt + 1}")
            else:
                insert_sql = """
                INSERT INTO streak (member_id, streak_type, streak_cnt, created_at, updated_at)
                VALUES (%s, %s, %s, %s, %s)
                """
                cursor.execute(insert_sql, (member_id, streak_type, 1, now_str, now_str))
                logger.info("새 streak 생성")

            conn.commit()

        except Exception as e:
            conn.rollback()
            logger.error(f"Streak 처리 중 오류: {e}")
            raise

        finally:
            cursor.close()
            conn.close()

    except Exception as e:
        logger.error(f"Streak DB 처리 오류: {e}")
        raise
