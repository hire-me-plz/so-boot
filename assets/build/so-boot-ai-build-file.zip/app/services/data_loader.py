"""
CSV 파일에서 CS 지식 데이터를 로드하는 모듈
"""

import pandas as pd
import os
import logging

# 로깅 설정
logger = logging.getLogger(__name__)

async def load_cs_data_from_csv(csv_file_path, vector_store):
    """
    CSV 파일에서 CS 데이터를 로드하고 ChromaDB에 삽입
    
    Args:
        csv_file_path: CSV 파일 경로
        vector_store: VectorStoreService 인스턴스
        
    Returns:
        처리된 문서 수
    """
    try:
        # CSV 파일 존재 확인
        if not os.path.exists(csv_file_path):
            logger.error(f"파일을 찾을 수 없습니다 - {csv_file_path}")
            return 0
            
        # CSV 파일 로드
        df = pd.read_csv(csv_file_path)
        logger.info(f"CSV 파일 로드 완료: {len(df)} 행")
        
        # 필수 열 확인
        required_columns = ['id', 'title', 'content', 'category', 'keywords']
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            logger.error(f"CSV 파일에 필수 열이 누락되었습니다 - {missing_columns}")
            return 0
        
        # 데이터 준비
        documents = []
        metadatas = []
        ids = []
        
        # 각 행 처리
        for idx, row in df.iterrows():
            # CSV 열 추출 (누락된 값은 빈 문자열로 대체)
            doc_id = str(row.get('id', f'cs_{idx}'))
            title = str(row.get('title', ''))
            content = str(row.get('content', ''))
            category = str(row.get('category', ''))
            keywords = str(row.get('keywords', ''))
            
            # 문서 내용 구성 (제목 + 내용)
            document = f"제목: {title}\n\n{content}"
            
            # 메타데이터 구성
            metadata = {
                'id': doc_id,
                'title': title,
                'category': category,
                'keywords': keywords,
                'type': 'cs_knowledge'  # 문서 유형 지정
            }
            
            # 리스트에 추가
            documents.append(document)
            metadatas.append(metadata)
            ids.append(doc_id)
        
        # ChromaDB에 일괄 추가
        logger.info(f"{len(documents)}개 문서 추가 중...")
        await vector_store.add_documents(documents, metadatas, ids)
        
        logger.info(f"ChromaDB에 {len(documents)}개 CS 문서 추가 완료")
        return len(documents)
    
    except Exception as e:
        logger.error(f"CS 데이터 로드 오류: {e}")
        return 0
