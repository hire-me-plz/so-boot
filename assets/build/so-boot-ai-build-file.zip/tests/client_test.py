"""
자소서 기반 면접 질문 생성 API 테스트 클라이언트

이 스크립트는 면접 질문 생성 API를 테스트하기 위한 간단한 클라이언트입니다.
"""

import requests
import json
import argparse
import os
from dotenv import load_dotenv

# 환경 변수 로드
load_dotenv()

# 기본 URL 설정
BASE_URL = os.getenv("API_URL", "http://localhost:8000")

def load_resume_data():
    """자소서 데이터 로드 API 호출"""
    url = f"{BASE_URL}/api/load-resume-data"
    
    try:
        response = requests.post(url)
        return response.json()
    except Exception as e:
        print(f"API 호출 오류: {e}")
        return None

def generate_questions(resume_id, member_id, job_title=None, num_questions=5):
    """면접 질문 생성 API 호출"""
    url = f"{BASE_URL}/api/generate-questions"
    
    data = {
        "resume_id": resume_id,
        "member_id": member_id,
        "num_questions": num_questions
    }
    
    if job_title:
        data["job_title"] = job_title
    
    try:
        response = requests.post(url, json=data)
        return response.json()
    except Exception as e:
        print(f"API 호출 오류: {e}")
        return None

def display_questions(result):
    """생성된 질문 결과 출력"""
    if not result or "questions" not in result:
        print("면접 질문이 생성되지 않았습니다.")
        return
    
    questions = result["questions"]
    print(f"\n총 {len(questions)}개의 면접 질문이 생성되었습니다.\n")
    
    for i, q in enumerate(questions, 1):
        print(f"질문 {i}: {q['question']}")
        print("\n평가 포인트:")
        for j, point in enumerate(q['evaluation_points'], 1):
            print(f"  {j}. {point}")
        
        print("\n모범 답안 키워드:")
        for j, keyword in enumerate(q['key_answer_points'], 1):
            print(f"  {j}. {keyword}")
        
        print("\n" + "-" * 80 + "\n")

def main():
    """메인 함수"""
    parser = argparse.ArgumentParser(description="자소서 기반 면접 질문 생성 API 테스트")
    parser.add_argument("--load", action="store_true", help="자소서 데이터 로드")
    parser.add_argument("--resume-id", type=int, help="자소서 ID")
    parser.add_argument("--member-id", type=int, help="회원 ID")
    parser.add_argument("--job-title", type=str, help="직무 타이틀")
    parser.add_argument("--num-questions", type=int, default=5, help="생성할 질문 수")
    
    args = parser.parse_args()
    
    # 자소서 데이터 로드
    if args.load:
        print("자소서 데이터를 로드합니다...")
        result = load_resume_data()
        if result:
            print(f"결과: {result}")
        return
    
    # 면접 질문 생성
    if args.resume_id and args.member_id:
        print(f"자소서 ID {args.resume_id}에 대한 면접 질문을 생성합니다...")
        result = generate_questions(
            resume_id=args.resume_id,
            member_id=args.member_id,
            job_title=args.job_title,
            num_questions=args.num_questions
        )
        
        if result:
            display_questions(result)
        return
    
    # 인수가 지정되지 않은 경우 상호작용 모드
    print("=== 자소서 기반 면접 질문 생성 API 테스트 ===")
    print("1. 자소서 데이터 로드")
    print("2. 면접 질문 생성")
    print("3. 종료")
    
    choice = input("\n선택: ")
    
    if choice == "1":
        print("\n자소서 데이터를 로드합니다...")
        result = load_resume_data()
        if result:
            print(f"결과: {result}")
    
    elif choice == "2":
        resume_id = int(input("\n자소서 ID: "))
        member_id = int(input("회원 ID: "))
        job_title = input("직무 타이틀 (선택사항): ")
        num_questions = int(input("생성할 질문 수 (기본값 5): ") or "5")
        
        print(f"\n자소서 ID {resume_id}에 대한 면접 질문을 생성합니다...")
        result = generate_questions(
            resume_id=resume_id,
            member_id=member_id,
            job_title=job_title if job_title else None,
            num_questions=num_questions
        )
        
        if result:
            display_questions(result)
    
    elif choice == "3":
        print("\n프로그램을 종료합니다.")
    
    else:
        print("\n잘못된 선택입니다.")

if __name__ == "__main__":
    main()
