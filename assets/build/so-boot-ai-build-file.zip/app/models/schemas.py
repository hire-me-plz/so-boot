"""
데이터 모델 정의
"""

from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime

# API 응답 래퍼 모델
class BaseResponse(BaseModel):
    """API 응답 래퍼"""
    isSuccess: bool = True
    code: int = 200
    message: str = "요청에 성공하였습니다."
    result: Any

# 자소서 데이터 관련 모델
class ResumeQuestion(BaseModel):
    question_id: int
    question_text: str

class ResumeAnswer(BaseModel):
    answer_id: int
    resume_id: int
    question_id: int
    answer_text: str

class ResumeData(BaseModel):
    resume_id: int
    member_id: int
    company_name: Optional[str] = None
    job_title: Optional[str] = None
    questions: List[ResumeQuestion]
    answers: List[ResumeAnswer]

# 면접 질문 생성 관련 모델
class InterviewQuestionRequest(BaseModel):
    resume_id: int = Field(..., description="자소서 ID")
    member_id: int = Field(..., description="회원 ID")
    company_name: Optional[str] = Field(None, description="회사")
    position: Optional[str] = Field(None, description="직무 타이틀")
    num_questions: int = Field(5, ge=1, le=10, description="생성할 질문 수 (1-10)")

# 생성된 면접 질문 모델
class GeneratedQuestion(BaseModel):
    """생성된 면접 질문"""
    question_text: str = Field(..., description="질문 내용")
    evaluation_points: List[str] = Field(..., description="평가 포인트")
    key_answer_points: List[str] = Field(..., description="모범 답안 키포인트")

# QuestionItem은 기존 코드와의 호환성을 위한 클래스
class QuestionItem(BaseModel):
    question: str = Field(..., description="면접 질문")
    evaluation_points: List[str] = Field(..., description="평가 요소")
    answer_key_points: List[str] = Field(..., description="모범 답안 키포인트")

# 면접 질문 생성 응답 모델
class InterviewQuestionResponse(BaseModel):
    """면접 질문 생성 응답"""
    resume_id: int = Field(..., description="자소서 ID")
    job_role: str = Field("Unknown", description="직무")
    experience_level: int = Field(0, description="경력 연차")
    questions: List[GeneratedQuestion] = Field(..., description="생성된 면접 질문 목록")

# 벡터 저장소 관련 모델
class VectorDocument(BaseModel):
    """벡터 저장소 문서"""
    id: str
    text: str
    metadata: Dict[str, Any]

class VectorSearchRequest(BaseModel):
    """벡터 검색 요청"""
    query: str = Field(..., description="검색 쿼리")
    filters: Optional[Dict[str, Any]] = Field(None, description="필터")
    limit: int = Field(5, ge=1, le=20, description="결과 제한 수")

class VectorSearchResult(BaseModel):
    """벡터 검색 결과"""
    documents: List[VectorDocument]
    distances: List[float]

# DB 저장 결과 모델
class SaveResult(BaseModel):
    """저장 결과"""
    success: bool
    message: str
    ids: List[int] = []

# 리허설 결과 관련 모델 (추가)
class QuestionAnswerPair(BaseModel):
    """질문과 답변 쌍"""
    question: str = Field(..., description="면접 질문")
    answer: str = Field(..., description="응답한 답변")

class RehearsalRequest(BaseModel):
    """리허설 결과 생성 요청"""
    memberId: int = Field(..., description="회원 ID")
    title: str = Field(..., description="리허설 제목")
    questions: List[QuestionAnswerPair] = Field(..., description="질문-답변 목록")
    position: Optional[str] = Field(None, description="직무 타이틀")

class QuestionFeedbackResponse(BaseModel):
    """질문 피드백 응답"""
    question: str = Field(..., description="면접 질문")
    answer: str = Field(..., description="응답한 답변")
    model_answer: str = Field(..., description="모범 답안")
    feedback_text: str = Field(..., description="피드백 내용")
    content_relevance_score: int = Field(..., ge=0, le=100, description="내용 적합성 점수 (0-100)")
    expertise_score: int = Field(..., ge=0, le=100, description="전문성 점수 (0-100)")
    job_fit_score: int = Field(..., ge=0, le=100, description="직무 적합성 점수 (0-100)")
    question_score: int = Field(..., ge=0, le=100, description="질문별 총점 (0-100)")

class RehearsalResultResponse(BaseModel):
    """리허설 결과 생성 응답"""
    rehearsal_result_id: int = Field(..., description="리허설 결과 ID")
    member_id: int = Field(..., description="회원 ID")
    title: str = Field(..., description="리허설 제목")
    total_score: int = Field(..., description="전체 평가 점수")
    created_at: datetime = Field(..., description="생성 일시")
    question_feedbacks: List[QuestionFeedbackResponse] = Field(..., description="질문 피드백 목록")
