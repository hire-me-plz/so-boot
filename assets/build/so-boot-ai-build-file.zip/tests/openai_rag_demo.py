import os
import time
import traceback
import logging
import sys
import io
import requests
import json
import numpy as np
from dotenv import load_dotenv
from openai import OpenAI

# 콘솔 출력 인코딩 설정 (Windows 환경용)
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

# ChromaDB 임포트
import chromadb
from chromadb import HttpClient
from langchain.schema import Document

# 로깅 설정 - UTF-8 인코딩 명시
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("rag_demo_debug.log", encoding='utf-8'),  # 인코딩 지정
        logging.StreamHandler(sys.stdout)
    ]
)

# 환경 변수 로드
load_dotenv()

def create_documents_from_texts(texts):
    """텍스트 리스트를 Document 객체로 변환"""
    documents = []
    for i, text in enumerate(texts):
        metadata = {"source": f"문서 {i+1}", "id": f"doc_{i}"}
        doc = Document(page_content=text, metadata=metadata)
        documents.append(doc)
    return documents

def print_section(title):
    """섹션 제목을 콘솔에 출력"""
    print(f"\n{'='*80}\n{title}\n{'='*80}")

def generate_embeddings(texts, api_key, model="text-embedding-3-small", dimensions=384):
    """OpenAI API를 사용하여 텍스트 임베딩을 생성 (직접 API 호출 방식)"""
    embeddings = []
    
    # 프록시 API URL - curl 명령과 동일한 형식 사용
    api_url = "https://gms.p.ssafy.io/gmsapi/api.openai.com/v1/embeddings"
    
    # 헤더 설정
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }
    
    for i, text in enumerate(texts):
        try:
            print(f"임베딩 {i+1}/{len(texts)} 생성 중...")
            logging.info(f"임베딩 {i+1}/{len(texts)} 생성 중...")
            
            # API 요청 데이터
            payload = {
                "model": model,
                "input": text,
                "dimensions": dimensions
            }
            
            # 직접 API 호출 (OpenAI 클라이언트 대신 requests 라이브러리 사용)
            response = requests.post(
                api_url,
                headers=headers,
                json=payload,
                timeout=30
            )
            
            # 응답 확인
            if response.status_code == 200:
                result = response.json()
                embedding = result["data"][0]["embedding"]
                embeddings.append(embedding)
                
                print(f"임베딩 {i+1} 생성 완료")
                logging.info(f"임베딩 {i+1} 생성 완료")
            else:
                error_msg = f"임베딩 API 오류: {response.status_code} - {response.text}"
                print(error_msg)
                logging.error(error_msg)
                raise Exception(error_msg)
            
            # API 호출 간 딜레이
            if i < len(texts) - 1:
                time.sleep(0.5)
                
        except Exception as e:
            print(f"임베딩 {i+1} 생성 중 오류: {str(e)}")
            logging.error(f"임베딩 {i+1} 생성 중 오류: {e}")
            logging.error(traceback.format_exc())
            raise
    
    return embeddings

def main():
    # API 키 확인
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        logging.error("오류: OPENAI_API_KEY 환경 변수가 설정되지 않았습니다.")
        print("오류: OPENAI_API_KEY 환경 변수가 설정되지 않았습니다. .env 파일을 확인해주세요.")
        return

    print_section("LangChain + ChromaDB RAG 시스템 데모 시작 (HttpClient + 커스텀 OpenAI 임베딩)")
    logging.info("LangChain + ChromaDB RAG 시스템 데모 시작 (HttpClient + 커스텀 OpenAI 임베딩)")

    # 1. 샘플 문서 내용
    texts = [
        "RAG는 언어 모델이 외부 지식 베이스를 참조하는 기술입니다.",
        "LLM은 대량의 데이터로 학습된 인공지능 모델입니다.",
        "Vector DB는 벡터 형태로 데이터를 저장하는 데이터베이스입니다.",
        "임베딩은 텍스트를 벡터로 변환하는 과정입니다."
    ]

    print("\n샘플 문서:")
    for i, text in enumerate(texts):
        print(f"  문서 {i+1}: {text}")
    
    logging.info(f"샘플 문서 {len(texts)}개 준비 완료")

    try:
        # 2. Document 객체 생성
        print_section("Document 객체 생성")
        documents = create_documents_from_texts(texts)
        print(f"Document 객체 {len(documents)}개 생성 완료")
        logging.info(f"Document 객체 {len(documents)}개 생성 완료")
        
        # 3. 임베딩 직접 생성
        print_section("커스텀 OpenAI 임베딩 직접 생성")
        
        try:
            # 텍스트 컨텐츠 추출
            text_contents = [doc.page_content for doc in documents]
            
            # 임베딩 직접 생성 함수 호출
            embeddings = generate_embeddings(text_contents, api_key)
            
            print(f"모든 임베딩 생성 완료: {len(embeddings)}개")
            logging.info(f"모든 임베딩 생성 완료: {len(embeddings)}개")
            
        except Exception as e:
            print(f"임베딩 생성 중 오류 발생: {str(e)}")
            logging.error(f"임베딩 생성 중 오류 발생: {e}")
            logging.error(traceback.format_exc())
            return
        
        # 4. ChromaDB HttpClient 초기화
        print_section("ChromaDB 초기화 (HttpClient 모드)")
        print("ChromaDB HTTP 클라이언트 초기화 중...")
        logging.info("ChromaDB HTTP 클라이언트 초기화 중...")

        # HttpClient 사용 - Docker로 실행 중인 ChromaDB 서버에 연결
        client = HttpClient(host="localhost", port=8000)

        print(f"ChromaDB 버전: {chromadb.__version__}")
        logging.info(f"ChromaDB 버전: {chromadb.__version__}")
        print("ChromaDB HTTP 클라이언트 초기화 완료")
        logging.info("ChromaDB HTTP 클라이언트 초기화 완료")
        
        # 컬렉션 ID 생성
        doc_ids = [f"doc_{i}" for i in range(len(documents))]
        
        # 5. 컬렉션 생성 및 문서 추가
        try:
            # 기존 컬렉션이 있으면 삭제
            try:
                client.delete_collection("rag_demo")
                print("기존 컬렉션 삭제 완료")
                logging.info("기존 컬렉션 삭제 완료")
            except Exception as e:
                print(f"기존 컬렉션 삭제 시도 중 정보 (무시 가능): {str(e)}")
                logging.info(f"기존 컬렉션 삭제 시도 중 정보: {e}")
            
            # 새 컬렉션 생성 (임베딩 함수 없이)
            print("새 컬렉션 생성 중...")
            collection = client.create_collection(
                name="rag_demo",
                metadata={"description": "RAG 데모 컬렉션"}
            )
            print("ChromaDB 컬렉션 생성 완료")
            logging.info("ChromaDB 컬렉션 생성 완료")
            
            # 문서 추가 시도
            print_section("직접 생성한 임베딩으로 문서 추가")
            print(f"생성한 임베딩과 함께 문서를 추가합니다...")
            logging.info("생성한 임베딩과 함께 문서를 추가합니다...")
            
            successful_docs = 0
            failed_docs = 0
            
            try:
                # 일괄 추가 시도 (직접 생성한 임베딩 사용)
                collection.add(
                    ids=doc_ids,
                    documents=[doc.page_content for doc in documents],
                    embeddings=embeddings,  # 직접 생성한 임베딩 사용
                    metadatas=[doc.metadata for doc in documents]
                )
                
                print("모든 문서 일괄 추가 완료!")
                logging.info("모든 문서 일괄 추가 완료")
                successful_docs = len(documents)
                
            except Exception as e:
                print(f"일괄 추가 중 오류: {str(e)}")
                logging.error(f"일괄 추가 중 오류: {e}")
                logging.error(traceback.format_exc())
                
                # 일괄 추가 실패시 하나씩 추가 시도
                print("문서를 하나씩 추가합니다...")
                
                for i, (doc, embedding) in enumerate(zip(documents, embeddings)):
                    try:
                        print(f"문서 {i+1}/{len(documents)} 추가 중...")
                        logging.info(f"문서 {i+1}/{len(documents)} 추가 중...")
                        
                        collection.add(
                            ids=[doc_ids[i]],
                            documents=[doc.page_content],
                            embeddings=[embedding],  # 개별 임베딩 사용
                            metadatas=[doc.metadata]
                        )
                        
                        print(f"문서 {i+1} 추가 성공!")
                        logging.info(f"문서 {i+1} 추가 성공")
                        
                        successful_docs += 1
                        time.sleep(1.0)  # 추가 사이 딜레이
                        
                    except Exception as e:
                        print(f"문서 {i+1} 추가 중 오류: {str(e)}")
                        logging.error(f"문서 {i+1} 추가 중 오류: {e}")
                        logging.error(traceback.format_exc())
                        failed_docs += 1
            
            print(f"\n문서 추가 완료: 성공 {successful_docs}개, 실패 {failed_docs}개")
            logging.info(f"문서 추가 완료: 성공 {successful_docs}개, 실패 {failed_docs}개")
            
            # 컬렉션 정보 확인
            count = collection.count()
            print(f"ChromaDB 컬렉션에 저장된 문서 수: {count}")
            logging.info(f"ChromaDB 컬렉션에 저장된 문서 수: {count}")
            
            if count == 0:
                print("오류: 컬렉션에 문서가 추가되지 않았습니다. 쿼리를 건너뜁니다.")
                logging.error("컬렉션에 문서가 추가되지 않음. 쿼리 건너뜀.")
                return
            
            # 6. 쿼리 실행 - 직접 임베딩 생성 사용
            print_section("질문 처리 (직접 임베딩 생성)")
            query = "RAG란?"
            print(f"질문: {query}")
            logging.info(f"\n질문: {query}")
            
            # 쿼리 임베딩 직접 생성
            print("쿼리 임베딩 생성 중...")
            logging.info("쿼리 임베딩 생성 중...")
            
            query_embeddings = generate_embeddings([query], api_key)
            query_embedding = query_embeddings[0]
            
            print("쿼리 임베딩 생성 완료")
            logging.info("쿼리 임베딩 생성 완료")
            
            # 7. 유사도 검색 실행 (직접 생성한 임베딩 사용)
            print("\n유사도 검색 실행 중...")
            results = collection.query(
                query_embeddings=[query_embedding],
                n_results=2
            )
            
            # 8. 결과 출력
            print_section("검색 결과")
            if results and "documents" in results and results["documents"] and len(results["documents"][0]) > 0:
                print(f"검색된 문서 수: {len(results['documents'][0])}")
                logging.info(f"검색된 문서 수: {len(results['documents'][0])}")
                
                for i, (doc, metadata, id, distance) in enumerate(zip(
                        results["documents"][0],
                        results["metadatas"][0],
                        results["ids"][0],
                        results["distances"][0])):
                    print(f"\n결과 {i+1} (유사도 점수: {1-distance:.4f}):")
                    print(f"  ID: {id}")
                    print(f"  출처: {metadata.get('source', '알 수 없음')}")
                    print(f"  내용: {doc}")
                    
                    logging.info(f"\n결과 {i+1} (거리: {distance}):")
                    logging.info(f"  ID: {id}")
                    logging.info(f"  출처: {metadata.get('source', '알 수 없음')}")
                    logging.info(f"  내용: {doc}")
            else:
                print("검색 결과가 없습니다.")
                logging.warning("검색 결과가 없습니다.")
                
        except Exception as e:
            print(f"ChromaDB 작업 중 오류: {e}")
            logging.error(f"ChromaDB 작업 중 오류: {e}")
            logging.error(traceback.format_exc())
            
        print_section("데모 완료")
        logging.info("\nLangChain + ChromaDB RAG 데모 완료!")
            
    except Exception as e:
        print(f"오류 발생: {e}")
        logging.error(f"오류 발생: {e}")
        logging.error(traceback.format_exc())

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"예상치 못한 오류 발생: {e}")
        logging.error(f"예상치 못한 오류 발생: {e}")
    finally:
        print("\n프로그램 종료")
        logging.info("프로그램 종료")
