# 개발자 면접 질문 생성 RAG 시스템

RAG(Retrieval-Augmented Generation) 기술을 활용한 개발자 면접 질문 생성 API 서버입니다.

## 개요

이 프로젝트는 LLM(Large Language Model)과 RAG 기술을 활용하여 개발자 직무별, 경력 수준별 맞춤형 면접 질문을 자동으로 생성하는 시스템입니다. 기존의 면접 질문 데이터를 벡터 데이터베이스에 저장하고, 사용자의 요청에 따라 관련된 질문들을 검색하여 이를 바탕으로 새로운 질문을 생성합니다.

## 주요 기능

- 개발자 직무(백엔드, 프론트엔드 등)별 면접 질문 생성
- 경력 수준에 맞는 난이도 조정
- 특정 기술 스택에 초점을 맞춘 질문 생성
- 자기소개서 분석을 통한 맞춤형 질문 생성
- 특정 기업 스타일의 면접 질문 생성 (선택적)

## 기술 스택

- **FastAPI**: 웹 API 프레임워크
- **LangChain**: LLM 애플리케이션 개발 프레임워크
- **Chroma**: 벡터 데이터베이스
- **OpenAI API**: 텍스트 임베딩 및 생성
- **Python 3.10+**: 프로그래밍 언어

## 설치 및 실행

### 1. 환경 설정

```bash
# 레포지토리 클론
git clone https://github.com/your-username/interview-question-generator.git
cd interview-question-generator

# 가상 환경 생성 및 활성화
python -m venv .venv
source .venv/bin/activate  # Linux/MacOS
# or
.venv\Scripts\activate  # Windows

# 의존성 설치
pip install -r requirements.txt
```

### 2. 환경 변수 설정

`.env` 파일을 프로젝트 루트에 생성하고 다음 내용을 추가합니다:

```
OPENAI_API_KEY=your_openai_api_key_here
PORT=8000
HOST=0.0.0.0
DEBUG=True
```

### 3. 서버 실행

```bash
python main.py
```

서버가 시작되면 `http://localhost:8000`에서 API에 접근할 수 있습니다.
API 문서는 `http://localhost:8000/docs`에서 확인할 수 있습니다.

## API 사용 예시

### 면접 질문 생성 요청

```bash
curl -X 'POST' \
  'http://localhost:8000/api/questions/generate' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{
  "job_role": "백엔드 개발자",
  "experience_level": 3,
  "num_questions": 5,
  "tech_stack": ["Python", "Django", "SQL"],
  "difficulty": "Medium"
}'
```

### 자기소개서 기반 면접 질문 생성

```bash
curl -X 'POST' \
  'http://localhost:8000/api/questions/generate' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{
  "job_role": "프론트엔드 개발자",
  "experience_level": 2,
  "num_questions": 5,
  "resume_text": "안녕하세요, 2년차 프론트엔드 개발자 홍길동입니다. 저는 React와 TypeScript를 주로 사용하며..."
}'
```

## 프로젝트 구조

```
interview-question-generator/
├── app/                         # 애플리케이션 코드
│   ├── models/                  # 데이터 모델 정의
│   │   └── schemas.py           # Pydantic 스키마
│   ├── routers/                 # API 라우터
│   │   └── questions.py         # 면접 질문 API 엔드포인트
│   └── services/                # 비즈니스 로직
│       ├── rag_service.py       # RAG 질문 생성 서비스
│       └── vector_store.py      # 벡터 저장소 관리
├── data/                        # 데이터 파일
│   ├── raw/                     # 원본 데이터
│   │   ├── companies.json       # 기업 정보
│   │   └── questions.json       # 면접 질문/답변
│   └── processed/               # 처리된 데이터
├── chroma_db/                   # Chroma 벡터 DB 저장소
├── tests/                       # 테스트 코드
├── .env                         # 환경 변수
├── main.py                      # 애플리케이션 진입점
├── requirements.txt             # 의존성 패키지
└── README.md                    # 문서
```


## 효율적인 벡터 저장 방법

1. **적절한 임베딩 모델 선택**: `text-embedding-3-small` 모델은 비용 효율적이면서도 충분한 성능을 제공합니다.

2. **메타데이터 활용**: 자소서 ID, 회원 ID, 회사 등의 메타데이터를 함께 저장하여 필터링에 활용합니다.

3. **청크 전략**: 자소서 전체와 각 질문-답변 쌍을 별도로 저장하여 다양한 검색 유형을 지원합니다.

4. **비동기 처리**: 벡터 저장소 연산을 비동기적으로 처리하여 API 응답 시간을 개선합니다.

## 면접 질문 생성을 위한 LLM 프롬프트 설계

프롬프트는 다음과 같은 주요 요소로 구성됩니다:

1. **역할 정의**: LLM에게 전문 면접관 역할을 부여합니다.
2. **자소서 컨텍스트**: 검색된 자소서 내용을 상세히 제공합니다.
3. **직무/회사 정보**: 회사와 직무 정보를 명시하여 맥락에 맞는 질문을 생성합니다.
4. **구체적인 지시**: 자소서 내용을 깊게 파고드는 구체적인 기술 질문과 상황 질문을 요청합니다.
5. **출력 형식**: 질문 텍스트, 평가 포인트, 모범 답안 키워드를 포함한 구조화된 출력을 요청합니다.

## 성능 최적화 방안

1. **벡터 저장소 인덱싱**: ChromaDB의 인덱싱 기능을 활용하여 검색 성능을 향상시킵니다.
2. **백그라운드 처리**: 시간이 오래 걸리는 작업은 백그라운드 태스크로 처리합니다.
3. **캐싱**: 자주 요청되는 데이터에 대한 캐싱을 구현합니다.
4. **배치 처리**: 데이터 로드 및 벡터화를 배치로 처리하여 효율성을 높입니다.
5. **비동기 API 호출**: 외부 API 호출은 비동기적으로 처리하여 병렬성을 높입니다.


## 참고 사항

- 첫 실행 시 Chroma 벡터 DB 초기화에 시간이 소요될 수 있습니다.
- OpenAI API 키는 유료 서비스이므로 사용량에 유의해주세요.
- 자기소개서를 통한 질문 생성 시, 지원자의 개인정보 보호에 주의하세요.
