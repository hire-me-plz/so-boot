"""
면접 리허설 평가 API 라우터

면접 리허설 답변을 평가하고 피드백을 생성하는 API
"""

from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from typing import Dict, Any
from fastapi.responses import JSONResponse
import logging

from ..services.rehearsal_service import RehearsalService
from ..services.vector_store import VectorStoreService
from ..models.schemas import (
    RehearsalRequest,
    QuestionAnswerPair,
    RehearsalResultResponse,
    BaseResponse
)

# 로깅 설정
logger = logging.getLogger(__name__)

# 라우터 생성
router = APIRouter(
    prefix="/fastapi/rehearsals",
    tags=["rehearsals"],
    responses={
        404: {"description": "Not found"},
        500: {"description": "Internal server error"}
    },
)

# 서비스 인스턴스
vector_store_service = None
rehearsal_service = None

# 의존성 주입: 벡터 저장소 서비스 제공
async def get_vector_store_service():
    global vector_store_service
    if vector_store_service is None:
        vector_store_service = VectorStoreService()
        await vector_store_service.initialize_collection()
    return vector_store_service

# 의존성 주입: 리허설 서비스 제공
async def get_rehearsal_service(vector_store: VectorStoreService = Depends(get_vector_store_service)):
    global rehearsal_service
    if rehearsal_service is None:
        rehearsal_service = RehearsalService(vector_store)
    return rehearsal_service

# API 엔드포인트: 면접 리허설 평가
@router.post("")
async def evaluate_rehearsal(
    request: RehearsalRequest,
    rehearsal_service: RehearsalService = Depends(get_rehearsal_service)
):
    """
    면접 리허설 답변 평가 및 피드백 생성

    Args:
        request: 리허설 평가 요청

    Returns:
        생성된 리허설 평가 결과
    """
    try:
        logger.info(f"리허설 평가 요청: 회원 ID {request.memberId}, 제목: {request.title}")
        
        # 형식 검증
        if not request.questions or len(request.questions) == 0:
            return JSONResponse(
                status_code=400,
                content={
                    "isSuccess": False,
                    "code": 400,
                    "message": "질문과 답변이 제공되지 않았습니다.",
                    "result": None
                }
            )
        
        # 리허설 평가 수행
        result, rehearsal_id = await rehearsal_service.evaluate_rehearsal(
            member_id=request.memberId,
            title=request.title,
            questions=[{"question": q.question, "answer": q.answer} for q in request.questions],
            position=request.position
        )
        
        if not result:
            return JSONResponse(
                status_code=500,
                content={
                    "isSuccess": False,
                    "code": 500,
                    "message": "리허설 평가 실패",
                    "result": None
                }
            )
        
        # 응답 구성
        wrapped_response = {
            "isSuccess": True,
            "code": 200,
            "message": "리허설 평가가 완료되었습니다.",
            "result": result
        }
        
        return JSONResponse(content=wrapped_response)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"리허설 평가 오류: {str(e)}")
        return JSONResponse(
            status_code=500,
            content={
                "isSuccess": False,
                "code": 500,
                "message": f"리허설 평가 중 오류 발생: {str(e)}",
                "result": None
            }
        )
