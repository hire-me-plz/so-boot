"""
RAG 시스템의 벡터 저장소 서비스 구현

ChromaDB를 사용하여 자소서 데이터를 벡터화하고 저장하는 서비스
Docker로 실행 중인 ChromaDB와 GMS API를 사용하여 임베딩 생성
"""

import os
import json
import time
import requests
from typing import List, Dict, Any, Optional, Tuple
import chromadb
from chromadb import HttpClient
from chromadb.utils import embedding_functions
from dotenv import load_dotenv
import logging
import mysql.connector
from mysql.connector import pooling

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

# 환경 변수 로드
load_dotenv()

def create_db_pool():
    """MySQL 연결 풀 생성"""
    try:
        pool = mysql.connector.pooling.MySQLConnectionPool(
            pool_name="mypool",
            pool_size=5,
            host=os.getenv("DB_HOST", "localhost"),
            user=os.getenv("DB_USER", "root"),
            password=os.getenv("DB_PASSWORD", ""),
            database=os.getenv("DB_NAME", "so_boot"),
            port=int(os.getenv("DB_PORT", "3306"))
        )
        logger.info("MySQL 연결 풀 생성 완료")
        return pool
    except Exception as e:
        logger.error(f"MySQL 연결 풀 생성 오류: {e}")
        raise

class GMSOpenAIEmbeddingFunction(embedding_functions.EmbeddingFunction):
    """GMS를 통해 OpenAI API를 호출하는 임베딩 함수"""

    def __init__(self, api_key: str, model_name: str = "text-embedding-3-small", dimensions: int = 1536):
        """
        GMS OpenAI 임베딩 함수 초기화
        
        Args:
            api_key: OpenAI API 키
            model_name: 임베딩 모델 이름
            dimensions: 임베딩 차원
        """
        self.api_key = api_key
        self.model_name = model_name
        self.dimensions = dimensions
        # GMS 프록시 URL 설정
        self.api_url = "https://gms.p.ssafy.io/gmsapi/api.openai.com/v1/embeddings"
        self.headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}"
        }
        logger.info(f"GMS OpenAI 임베딩 함수 초기화: {model_name}, 차원: {dimensions}")

    def __call__(self, texts: List[str]) -> List[List[float]]:
        """
        텍스트 목록에 대한 임베딩 생성
        
        Args:
            texts: 임베딩할 텍스트 목록
            
        Returns:
            생성된 임베딩 목록
        """
        embeddings = []
        
        for i, text in enumerate(texts):
            try:
                # API 요청 데이터 구성
                payload = {
                    "model": self.model_name,
                    "input": text,
                    "dimensions": self.dimensions
                }
                
                # GMS를 통한 OpenAI API 호출
                response = requests.post(
                    self.api_url,
                    headers=self.headers,
                    json=payload,
                    timeout=30
                )
                
                # 응답 확인
                if response.status_code == 200:
                    result = response.json()
                    embedding = result["data"][0]["embedding"]
                    embeddings.append(embedding)
                    logger.debug(f"임베딩 {i+1}/{len(texts)} 생성 완료")
                else:
                    error_msg = f"임베딩 API 오류: {response.status_code} - {response.text}"
                    logger.error(error_msg)
                    raise Exception(error_msg)
                
                # 연속 호출 사이에 짧은 지연 추가 (API 호출 제한 방지)
                if i < len(texts) - 1:
                    time.sleep(0.5)
                
            except Exception as e:
                logger.error(f"임베딩 생성 중 오류: {str(e)}")
                # 오류 발생 시 영벡터 반환 (임시 방편, 나중에 더 나은 오류 처리 구현 필요)
                embeddings.append([0.0] * self.dimensions)
        
        return embeddings

class VectorStoreService:
    def __init__(self, collection_name: str = "resume_embeddings"):
        """벡터 저장소 서비스 초기화"""
        # OpenAI API 키 설정
        self.openai_api_key = os.getenv("OPENAI_API_KEY")
        if not self.openai_api_key:
            raise ValueError("OpenAI API 키가 필요합니다. 환경 변수에 OPENAI_API_KEY를 설정해주세요.")
        
        # ChromaDB 호스트 및 포트 설정
        self.chroma_host = os.getenv("CHROMA_HOST", "localhost")
        self.chroma_port = int(os.getenv("CHROMA_PORT", "8001"))
        
        # ChromaDB HttpClient 및 GMS 임베딩 함수 초기화
        try:
            self.client = HttpClient(host=self.chroma_host, port=self.chroma_port)
            logger.info(f"ChromaDB HTTP 클라이언트 초기화 완료 (호스트: {self.chroma_host}, 포트: {self.chroma_port})")
            
            self.embedding_function = GMSOpenAIEmbeddingFunction(
                api_key=self.openai_api_key,
                model_name="text-embedding-3-small", 
                dimensions=1536
            )
            logger.info("GMS OpenAI 임베딩 함수 초기화 완료")
        except Exception as e:
            logger.error(f"ChromaDB 또는 임베딩 함수 초기화 오류: {e}")
            raise
        
        # 컬렉션 이름 저장
        self.collection_name = collection_name
        
        # 기본 컬렉션 변수 초기화
        self.collection = None
        
    async def initialize_collection(self, force_recreate: bool = False):
        """ChromaDB 컬렉션 초기화 또는 가져오기"""
        try:
            # 강제 재생성 플래그가 설정된 경우 기존 컬렉션 삭제
            if force_recreate:
                try:
                    self.client.delete_collection(self.collection_name)
                    logger.info(f"기존 {self.collection_name} 컬렉션을 삭제했습니다.")
                except Exception as e:
                    logger.info(f"컬렉션 삭제 시도 중 정보 (무시 가능): {str(e)}")
            
            # 기존 컬렉션이 있으면 가져오기
            try:
                self.collection = self.client.get_collection(
                    name=self.collection_name,
                    embedding_function=self.embedding_function
                )
                count = self.collection.count()
                logger.info(f"기존 {self.collection_name} 컬렉션을 가져왔습니다. (문서 수: {count})")
            except Exception as e:
                # 없으면 새로 생성
                self.collection = self.client.create_collection(
                    name=self.collection_name,
                    embedding_function=self.embedding_function,
                    metadata={"description": "자소서 데이터 벡터 저장소"}
                )
                logger.info(f"새 {self.collection_name} 컬렉션을 생성했습니다.")
            
        except Exception as e:
            logger.error(f"컬렉션 초기화 오류: {e}")
            raise
            
        return self.collection
    
    async def add_document(self, document: str, metadata: Dict[str, Any], doc_id: str):
        """단일 문서를 벡터 저장소에 추가"""
        if self.collection is None:
            await self.initialize_collection()
            
        try:
            # ChromaDB에 추가
            self.collection.add(
                documents=[document],
                metadatas=[metadata],
                ids=[doc_id]
            )
            
            logger.info(f"문서 ID '{doc_id}'가 컬렉션에 추가되었습니다.")
        except Exception as e:
            logger.error(f"문서 추가 오류 (ID: {doc_id}): {e}")
            raise
        
    async def add_documents(self, documents: List[str], metadatas: List[Dict[str, Any]], ids: List[str]):
        """여러 문서를 벡터 저장소에 추가"""
        if self.collection is None:
            await self.initialize_collection()
        
        # 입력 길이 확인
        if len(documents) != len(metadatas) or len(documents) != len(ids):
            raise ValueError("documents, metadatas, ids의 길이가 일치해야 합니다.")
        
        # 문서가 없으면 무시
        if not documents:
            logger.warning("추가할 문서가 없습니다.")
            return
            
        try:
            # 일괄 추가 시도
            self.collection.add(
                documents=documents,
                metadatas=metadatas,
                ids=ids
            )
            
            logger.info(f"{len(documents)}개 문서가 컬렉션에 추가되었습니다.")
        except Exception as e:
            logger.error(f"일괄 문서 추가 오류: {e}")
            
            # 오류 발생 시 문서를 하나씩 추가 시도
            successful_docs = 0
            failed_docs = 0
            
            for i, (doc, metadata, doc_id) in enumerate(zip(documents, metadatas, ids)):
                try:
                    logger.info(f"문서 {i+1}/{len(documents)} 개별 추가 시도...")
                    
                    self.collection.add(
                        documents=[doc],
                        metadatas=[metadata],
                        ids=[doc_id]
                    )
                    
                    successful_docs += 1
                    # 연속 추가 간 짧은 지연 추가
                    time.sleep(0.5)
                    
                except Exception as inner_e:
                    logger.error(f"문서 {i+1} 개별 추가 오류: {inner_e}")
                    failed_docs += 1
            
            logger.info(f"개별 추가 결과: 성공 {successful_docs}개, 실패 {failed_docs}개")
            
            if successful_docs == 0:
                raise ValueError("모든 문서 추가 실패")
    
    async def query(self, query_text: str, filters: Optional[Dict[str, Any]] = None, n_results: int = 5):
        """벡터 저장소에서 쿼리 수행"""
        if self.collection is None:
            await self.initialize_collection()
            
        try:
            # 쿼리 텍스트 로깅
            logger.info(f"쿼리 텍스트: {query_text[:100]}...")
            
            # 임베딩 직접 생성 (GMS 사용)
            query_embedding = self.embedding_function([query_text])[0]
            
            # 쿼리 파라미터 설정
            params = {
                "query_embeddings": [query_embedding],
                "n_results": n_results
            }
            
            # 필터 추가 (있는 경우)
            if filters:
                params["where"] = filters
                logger.info(f"필터 적용: {filters}")
            
            # 검색 수행
            results = self.collection.query(**params)
            logger.info(f"쿼리 결과: {len(results['ids'][0])}개 문서 검색됨")
            
            return results
            
        except Exception as e:
            logger.error(f"쿼리 수행 오류: {e}")
            # 빈 결과 반환
            return {
                "ids": [[]],
                "documents": [[]],
                "metadatas": [[]],
                "distances": [[]]
            }
    
    async def get_collection_info(self):
        """벡터 저장소 컬렉션 정보 조회"""
        if self.collection is None:
            await self.initialize_collection()
            
        try:
            count = self.collection.count()
            return {
                "name": self.collection_name,
                "count": count,
                "metadata": self.collection.get()
            }
        except Exception as e:
            logger.error(f"컬렉션 정보 조회 오류: {e}")
            return {
                "name": self.collection_name,
                "count": 0,
                "error": str(e)
            }
        
    async def fetch_resume_data_from_db(self, resume_id: Optional[int] = None):
        """
        DB에서 자소서 데이터 가져오기
        
        Args:
            resume_id: 자소서 ID (None인 경우 전체 자소서)
            
        Returns:
            자소서 데이터 리스트
        """
        try:
            # DB 연결 풀에서 연결 가져오기
            pool = create_db_pool()
            conn = pool.get_connection()
            cursor = conn.cursor(dictionary=True)
            
            # SQL 쿼리 구성
            if resume_id:
                # 특정 자소서 데이터 쿼리
                query = """
                SELECT r.resume_id, r.member_id, r.position, r.company_name, 
                       re.entry_question, re.entry_answer
                FROM resume r
                JOIN resume_entry re ON r.resume_id = re.resume_id
                WHERE r.resume_id = %s
                """
                cursor.execute(query, (resume_id,))
            else:
                # 모든 자소서 데이터 쿼리
                query = """
                SELECT r.resume_id, r.member_id, r.position, r.company_name, 
                       re.entry_question, re.entry_answer
                FROM resume r
                JOIN resume_entry re ON r.resume_id = re.resume_id
                """
                cursor.execute(query)
            
            # 결과 가져오기
            results = cursor.fetchall()
            
            # 연결 종료
            cursor.close()
            conn.close()
            
            # 결과 정리
            resumes = {}
            for row in results:
                resume_id = row['resume_id']
                
                # 자소서 정보 정리
                if resume_id not in resumes:
                    resumes[resume_id] = {
                        'resume_id': resume_id,
                        'member_id': row['member_id'],
                        'position': row['position'],
                        'company_name': row['company_name'],
                        'entries': []
                    }
                
                # 자소서 항목 추가
                resumes[resume_id]['entries'].append({
                    'question': row['entry_question'],
                    'answer': row['entry_answer']
                })
            
            # 자소서 리스트로 변환
            resume_list = list(resumes.values())
            logger.info(f"{len(resume_list)}개 자소서 데이터 조회 완료")
            
            return resume_list
            
        except Exception as e:
            logger.error(f"자소서 데이터 조회 오류: {e}")
            return []
            
    async def process_and_store_resume_data(self, resume_data_list):
        """
        자소서 데이터 처리 및 벡터 저장소에 저장
        
        Args:
            resume_data_list: 자소서 데이터 리스트
            
        Returns:
            처리된 문서 수
        """
        try:
            documents = []
            metadatas = []
            ids = []
            
            doc_count = 0
            
            for resume in resume_data_list:
                resume_id = resume['resume_id']
                
                # 전체 자소서 내용 통합 (모든 항목 결합)
                full_content = "\n\n".join([
                    f"질문: {entry['question']}\n답변: {entry['answer']}"
                    for entry in resume['entries']
                ])
                
                # 전체 자소서 추가
                documents.append(full_content)
                metadatas.append({
                    'resume_id': resume_id,
                    'member_id': resume['member_id'],
                    'position': resume['position'],
                    'company_name': resume['company_name'],
                    'type': 'full_resume'
                })
                ids.append(f"resume_{resume_id}")
                doc_count += 1
                
                # 개별 항목도 추가
                for i, entry in enumerate(resume['entries']):
                    entry_content = f"질문: {entry['question']}\n답변: {entry['answer']}"
                    documents.append(entry_content)
                    metadatas.append({
                        'resume_id': resume_id,
                        'member_id': resume['member_id'],
                        'position': resume['position'],
                        'company_name': resume['company_name'],
                        'type': 'resume_entry',
                        'entry_index': i
                    })
                    ids.append(f"resume_{resume_id}_entry_{i}")
                    doc_count += 1
            
            # 벡터 저장소에 추가
            if documents:
                await self.add_documents(documents, metadatas, ids)
                logger.info(f"{doc_count}개 자소서 문서 처리 및 저장 완료")
            
            return doc_count
            
        except Exception as e:
            logger.error(f"자소서 데이터 처리 및 저장 오류: {e}")
            return 0
            
    async def query_similar_documents(self, query_text, filters=None, n_results=5):
        """
        벡터 저장소에서 유사한 문서 검색
        
        Args:
            query_text: 검색 쿼리 텍스트
            filters: 필터 조건
            n_results: 검색 결과 수
            
        Returns:
            검색 결과
        """
        try:
            # 쿼리 수행
            results = await self.query(query_text, filters, n_results)
            return results
        except Exception as e:
            logger.error(f"유사 문서 검색 오류: {e}")
            # 빈 결과 반환
            return {
                "ids": [[]],
                "documents": [[]],
                "metadatas": [[]],
                "distances": [[]]
            }

    async def save_generated_questions_to_db(self, resume_id, member_id,
        questions):
        """
        생성된 면접 질문을 DB에 저장

        Args:
            resume_id: 자소서 ID
            member_id: 회원 ID
            questions: 생성된 질문 리스트

        Returns:
            저장 성공 여부, 저장된 질문 ID 리스트
        """
        try:
            # datetime 모듈 임포트
            from datetime import datetime

            # DB 연결 풀에서 연결 가져오기
            pool = create_db_pool()
            conn = pool.get_connection()
            cursor = conn.cursor()

            saved_ids = []

            # 트랜잭션 시작
            conn.start_transaction()

            # 자소서에서 회사 이름 가져오기 (Resume 테이블에서 company_name 조회)
            company_name_query = """
            SELECT company_name FROM resume WHERE resume_id = %s
            """
            cursor.execute(company_name_query, (resume_id,))
            company_name_result = cursor.fetchone()
            company_name = company_name_result[
                0] if company_name_result else None

            # 현재 시간 설정
            current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            for q in questions:
                # question 테이블에 저장 (created_at 필드 명시적 설정)
                q_query = """
                INSERT INTO question (question, question_type, created_at,updated_at)
                VALUES (%s, 'C_LETTER', %s, %s)
                """
                cursor.execute(q_query, (q['question_text'], current_time, current_time))

                # 생성된 question_id 가져오기
                question_id = cursor.lastrowid
                saved_ids.append(question_id)

                # c_letter_question 테이블에 저장 (company_name 필드 사용, created_at 필드 추가)
                cl_query = """
                INSERT INTO c_letter_question (member_id, question_id, company_name, created_at, updated_at, resume_id)
                VALUES (%s, %s, %s, %s, %s, %s)
                """
                cursor.execute(cl_query, (
                    member_id, question_id, company_name, current_time, current_time, resume_id))

            # 트랜잭션 커밋
            conn.commit()

            # 연결 종료
            cursor.close()
            conn.close()

            logger.info(f"{len(saved_ids)}개 질문 DB 저장 완료")
            return True, saved_ids

        except Exception as e:
            # 오류 발생 시 롤백
            if 'conn' in locals() and conn.is_connected():
                conn.rollback()
                conn.close()

            logger.error(f"질문 DB 저장 오류: {e}")
            return False, None