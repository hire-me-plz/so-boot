import chromadb
from chromadb.utils.embedding_functions import OpenAIEmbeddingFunction, SentenceTransformerEmbeddingFunction
import os
import time
from dotenv import load_dotenv

# 환경 변수 로드
load_dotenv()

def test_openai_embedding():
    print("\n===== OpenAI 임베딩 테스트 =====")
    # API 키 확인
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("오류: OPENAI_API_KEY 환경 변수가 설정되지 않았습니다.")
        print(".env 파일에 OPENAI_API_KEY를 설정하세요.")
        return False
    
    try:
        # 임베딩 함수 설정
        print("OpenAI 임베딩 함수 초기화 중...")
        start_time = time.time()
        
        embedding_function = OpenAIEmbeddingFunction(
            api_key=api_key,
            model_name="text-embedding-3-small",
            dimensions=512
        )
        print(f"OpenAI 임베딩 함수 초기화 완료! (소요 시간: {time.time() - start_time:.2f}초)")
        
        # 테스트 임베딩 생성
        test_text = "이것은 임베딩 테스트 문장입니다."
        print(f"\n테스트 텍스트 임베딩 생성 중: '{test_text}'")
        start_time = time.time()
        
        embedding = embedding_function([test_text])
        
        print(f"임베딩 생성 완료! (소요 시간: {time.time() - start_time:.2f}초)")
        print(f"임베딩 차원: {len(embedding[0])}")
        print(f"임베딩 샘플 (처음 5개 값): {embedding[0][:5]}")
        
        return True
    except Exception as e:
        print(f"OpenAI 임베딩 테스트 중 오류 발생: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_sentence_transformer_embedding():
    print("\n===== SentenceTransformer 임베딩 테스트 =====")
    try:
        # 임베딩 함수 설정
        print("SentenceTransformer 임베딩 함수 초기화 중...")
        start_time = time.time()
        
        embedding_function = SentenceTransformerEmbeddingFunction(
            model_name="sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
        )
        print(f"SentenceTransformer 임베딩 함수 초기화 완료! (소요 시간: {time.time() - start_time:.2f}초)")
        
        # 테스트 임베딩 생성
        test_text = "이것은 임베딩 테스트 문장입니다."
        print(f"\n테스트 텍스트 임베딩 생성 중: '{test_text}'")
        start_time = time.time()
        
        embedding = embedding_function([test_text])
        
        print(f"임베딩 생성 완료! (소요 시간: {time.time() - start_time:.2f}초)")
        print(f"임베딩 차원: {len(embedding[0])}")
        print(f"임베딩 샘플 (처음 5개 값): {embedding[0][:5]}")
        
        return True
    except Exception as e:
        print(f"SentenceTransformer 임베딩 테스트 중 오류 발생: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    print(f"ChromaDB 버전: {chromadb.__version__}")
    
    # 선택 메뉴
    print("\n임베딩 함수 테스트 메뉴:")
    print("1. OpenAI 임베딩 테스트")
    print("2. SentenceTransformer 임베딩 테스트")
    print("3. 둘 다 테스트")
    
    choice = input("\n선택 (1-3): ")
    
    if choice == "1":
        test_openai_embedding()
    elif choice == "2":
        test_sentence_transformer_embedding()
    elif choice == "3":
        print("\n두 임베딩 함수 모두 테스트합니다...")
        openai_success = test_openai_embedding()
        st_success = test_sentence_transformer_embedding()
        
        print("\n===== 테스트 결과 요약 =====")
        print(f"OpenAI 임베딩: {'성공' if openai_success else '실패'}")
        print(f"SentenceTransformer 임베딩: {'성공' if st_success else '실패'}")
    else:
        print("잘못된 선택입니다. 1, 2, 3 중에서 선택하세요.")

if __name__ == "__main__":
    main()
