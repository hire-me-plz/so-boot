# OpenAI 임베딩 모델 사용 가이드

이 문서는 so-boot-ai 프로젝트에서 OpenAI 임베딩 모델을 사용하는 방법에 대한 안내입니다.

## 최신 임베딩 모델 정보

OpenAI는 최근 새로운 임베딩 모델을 출시했습니다:

* `text-embedding-3-small`: 비용 효율적인 모델 (1536 차원)
* `text-embedding-3-large`: 성능이 우수한 모델 (3072 차원)

이 프로젝트에서는 `text-embedding-3-small` 모델을 사용하며, 필요에 따라 차원을 조정할 수 있습니다.

## 설정 방법

### 1. API 키 설정

`.env` 파일에 OpenAI API 키를 설정해야 합니다:

```
OPENAI_API_KEY=your_actual_openai_api_key_here
```

### 2. 임베딩 함수 초기화

```python
from chromadb.utils.embedding_functions import OpenAIEmbeddingFunction

embedding_function = OpenAIEmbeddingFunction(
    api_key=api_key,
    model_name="text-embedding-3-small",  # 최신 모델 사용
    dimensions=1024  # 선택적으로 차원 조정 가능 (기본값: 1536)
)
```

### 3. 컬렉션 생성 시 임베딩 함수 지정

```python
collection = client.create_collection(
    name="collection_name",
    embedding_function=embedding_function,
    metadata={"description": "컬렉션 설명"}
)
```

## 차원 조정 (Dimensionality)

임베딩 차원을 조정하여 비용과 성능 사이의 균형을 맞출 수 있습니다:

```python
# 차원 축소 예시
embedding_function = OpenAIEmbeddingFunction(
    api_key=api_key,
    model_name="text-embedding-3-small",
    dimensions=1024  # 1536(기본값)에서 축소
)
```

차원을 줄이면:
- 저장 공간 감소
- 검색 속도 향상
- API 호출 비용 감소
- 다만 정확도는 약간 저하될 수 있음

## 테스트 파일

프로젝트에는 OpenAI 임베딩을 테스트하기 위한 여러 파일이 포함되어 있습니다:

1. `test_chromadb_openai.py`: 기본적인 OpenAI 임베딩 테스트
2. `openai_rag_demo.py`: OpenAI 임베딩을 사용한 RAG 시스템 데모

## 실행 방법

```bash
# 기본 테스트
python test_chromadb_openai.py

# RAG 데모
python openai_rag_demo.py
```

## 성능 최적화

1. **차원 조정**: 애플리케이션 요구사항에 맞게 차원 조정
2. **일괄 처리**: 가능한 경우 여러 문서를 일괄 처리하여 API 호출 최소화
3. **캐싱**: 자주 사용되는 임베딩 결과 캐싱 고려

## 비용 관리

OpenAI 임베딩은 입력 토큰당 비용이 발생합니다. 비용을 관리하려면:

1. 불필요하게 긴 텍스트 피하기
2. 중복 임베딩 줄이기 
3. `text-embedding-3-small` 사용하기 (large보다 비용 효율적)
4. 차원 축소하기 (비용 절감에 도움)

## 참고 문서

자세한 정보는 OpenAI 공식 문서를 참조하세요:
- [OpenAI 임베딩 가이드](https://platform.openai.com/docs/guides/embeddings)
- [임베딩 모델 비교](https://platform.openai.com/docs/guides/embeddings/embedding-models)
