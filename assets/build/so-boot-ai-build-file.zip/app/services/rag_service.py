"""
RAG(Retrieval-Augmented Generation) 서비스

자소서 데이터를 기반으로 면접 질문을 생성하는 RAG 서비스
CS 지식 데이터를 활용하여 기술 면접 질문을 강화
"""

import os
import json
import logging
from typing import List, Dict, Any, Optional, Tuple
import requests
from datetime import datetime

from .vector_store import VectorStoreService

# 로깅 설정
logger = logging.getLogger(__name__)

class RAGService:
    """RAG 서비스"""

    def __init__(self, vector_store_service: VectorStoreService):
        """
        RAG 서비스 초기화

        Args:
            vector_store_service: 벡터 저장소 서비스 인스턴스
        """
        # 벡터 저장소 서비스 설정
        self.vector_store_service = vector_store_service

        # OpenAI API 키 설정
        self.openai_api_key = os.getenv("OPENAI_API_KEY")
        if not self.openai_api_key:
            raise ValueError("OpenAI API 키가 필요합니다. 환경 변수에 OPENAI_API_KEY를 설정해주세요.")

        # OpenAI API 설정 - GMS URL로 수정
        self.api_endpoint = "https://gms.p.ssafy.io/gmsapi/api.openai.com/v1/chat/completions"
        self.api_headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.openai_api_key}"
        }
    
    async def fetch_and_process_resume_data(self, resume_id: Optional[int] = None) -> int:
        """
        자소서 데이터 가져오기 및 처리
        
        Args:
            resume_id: 자소서 ID (None인 경우 모든 자소서 처리)
            
        Returns:
            처리된 문서 수
        """
        # DB에서 자소서 데이터 불러오기
        resume_data = await self.vector_store_service.fetch_resume_data_from_db(resume_id)
        
        if not resume_data:
            logger.warning(f"자소서 ID {resume_id or '전체'}에 대한 데이터를 찾을 수 없습니다.")
            return 0
        
        # 자소서 데이터 처리 및 저장
        doc_count = await self.vector_store_service.process_and_store_resume_data(resume_data)
        
        return doc_count
    
    async def generate_interview_questions(self,
                                resume_id: int,
                                member_id: int,
                                company_name: Optional[str] = None,  # 변경: company_id → company_name
                                position: Optional[str] = None,
                                num_questions: int = 5,
                                save_to_db: bool = True) -> Tuple[List[Dict[str, Any]], Optional[List[int]]]:
        """
        자소서 기반 면접 질문 생성
        
        Args:
            resume_id: 자소서 ID
            member_id: 회원 ID
            company_name: 회사 이름
            position: 직무 타이틀 (옵션)
            num_questions: 생성할 질문 수
            save_to_db: 생성된 질문을 DB에 저장할지 여부
            
        Returns:
            생성된 질문 리스트, 저장된 질문 ID 리스트 (저장 시)
        """
        # 벡터 저장소에서 자소서 검색
        filters = {"resume_id": resume_id}
        query_text = f"자소서 ID {resume_id} {position or ''}"
        
        results = await self.vector_store_service.query_similar_documents(
            query_text=query_text,
            filters=filters,
            n_results=5
        )
        
        # 검색 결과가 없는 경우
        if not results["documents"][0]:
            logger.warning(f"자소서 ID {resume_id}에 대한 검색 결과가 없습니다.")
            # 자소서 데이터를 가져와서 처리
            doc_count = await self.fetch_and_process_resume_data(resume_id)
            if doc_count == 0:
                logger.error(f"자소서 ID {resume_id}에 대한 데이터를 찾을 수 없습니다.")
                return [], None
            
            # 다시 검색
            results = await self.vector_store_service.query_similar_documents(
                query_text=query_text,
                filters=filters,
                n_results=5
            )
            
            # 여전히 결과가 없으면 오류
            if not results["documents"][0]:
                logger.error(f"자소서 ID {resume_id}에 대한 검색 결과가 없습니다.")
                return [], None
        
        # 검색된 자소서 내용 결합
        resume_content = "\n\n".join(results["documents"][0])
        
        # 메타데이터에서 정보 추출
        metadatas = results["metadatas"][0]
        company_name = metadatas[0].get("company_name", "회사")
        job_position = position or metadatas[0].get("position", "직무")
        
        # OpenAI API 요청 구성
        prompt = f"""
        당신은 {company_name}의 {job_position} 직무 면접관입니다. 
        다음 자기소개서를 분석한 후, 지원자에게 물을 수 있는 {num_questions}개의 기술 면접 질문을 생성해주세요.
        
        질문은 자소서 내용을 깊게 파고들 수 있는 구체적인 것이어야 하며, 지원자의 역량과 경험을 검증할 수 있어야 합니다.
        단순히 자소서 내용을 확인하는 질문이 아닌, 자소서를 기반으로 깊이 있는 기술적 질문과 상황 질문을 만들어 주세요.
        
        자기소개서:
        {resume_content}
        
        각 질문에는 면접관이 평가할 수 있는 '평가 포인트'와 '모범 답안 키워드'도 함께 제공해주세요.
        
        응답 형식:
        [
          {{
            "question_text": "질문 내용",
            "evaluation_points": ["평가 포인트1", "평가 포인트2", ...],
            "key_answer_points": ["모범 답안 키워드1", "모범 답안 키워드2", ...]
          }},
          ...
        ]
        
        응답은 반드시 유효한 JSON 형식으로 제공해주세요.
        """
        
        # API 요청 데이터
        data = {
            "model": "gpt-4o", # 또는 "gpt-3.5-turbo"
            "messages": [
                {"role": "system", "content": "당신은 전문 기술 면접관입니다."},
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.7
        }
        
        try:
            # OpenAI API 호출
            logger.info(f"OpenAI API 호출: {job_position} 직무 면접 질문 생성")
            response = requests.post(self.api_endpoint, headers=self.api_headers, json=data)
            response.raise_for_status()  # 오류 발생 시 예외 발생
            
            response_data = response.json()
            
            # 응답 파싱
            content = response_data['choices'][0]['message']['content']

            # 백틱(```)으로 감싸진 JSON 문자열 추출
            if '```json' in content:
                # JSON 코드 블록에서 JSON 부분만 추출
                json_content = content.split('```json')[1].split('```')[0].strip()
                questions = json.loads(json_content)
            elif '```' in content:
                # 일반 코드 블록에서 JSON 부분만 추출
                json_content = content.split('```')[1].split('```')[0].strip()
                questions = json.loads(json_content)
            else:
                # 일반 텍스트에서 JSON 파싱 시도
                questions = json.loads(content)
            
            logger.info(f"{len(questions)}개 면접 질문 생성 완료")
            
            # 생성된 질문을 DB에 저장 (옵션)
            saved_ids = None
            if save_to_db:
                success, saved_ids = await self.vector_store_service.save_generated_questions_to_db(
                    resume_id=resume_id,
                    member_id=member_id,
                    questions=questions
                )
                
                if not success:
                    logger.warning("DB 저장에 실패했습니다.")
            
            # CS 지식으로 질문 강화 시도
            try:
                enhanced_questions = await self.enhance_with_cs_knowledge(questions, resume_content)
                if enhanced_questions:
                    questions = enhanced_questions
                    logger.info("CS 지식을 활용하여 질문이 강화되었습니다.")
            except Exception as enhance_error:
                logger.warning(f"CS 지식 강화 중 오류 (무시됨): {enhance_error}")
            
            return questions, saved_ids
            
        except requests.exceptions.RequestException as e:
            logger.error(f"API 요청 오류: {e}")
            if 'response' in locals():
                logger.error(f"응답 코드: {response.status_code}, 응답: {response.text}")
            return [], None
            
        except (KeyError, json.JSONDecodeError) as e:
            logger.error(f"API 응답 파싱 오류: {e}")
            if 'response_data' in locals():
                logger.error(f"원본 응답: {response_data}")
            return [], None
            
    async def enhance_with_cs_knowledge(self, questions, resume_content):
        """
        면접 질문을 CS 지식으로 강화
        
        Args:
            questions: 기존 생성된 질문 리스트
            resume_content: 자소서 내용
            
        Returns:
            CS 지식으로 강화된 질문 리스트
        """
        try:
            # 자소서에서 키워드 추출
            tech_keywords = self._extract_tech_keywords(resume_content)
            
            if not tech_keywords:
                logger.info("자소서에서 기술 키워드를 찾을 수 없습니다.")
                return questions
                
            # CS 지식 검색
            cs_query = " ".join(tech_keywords[:5])  # 상위 5개 키워드 사용
            
            cs_results = await self.vector_store_service.query_similar_documents(
                query_text=cs_query,
                filters={"type": "cs_knowledge"},
                n_results=3
            )
            
            # CS 지식 검색 결과가 없는 경우
            if not cs_results["documents"][0]:
                logger.info("관련 CS 지식을 찾을 수 없습니다.")
                return questions
                
            # CS 지식 컨텍스트 구성
            cs_context = "\n\n".join([
                f"CS 참고 자료 {i+1}: {cs_results['metadatas'][0][i].get('title', '참고 자료')}\n{doc}"
                for i, doc in enumerate(cs_results["documents"][0][:2])
            ])
            
            # OpenAI API 요청으로 CS 지식 기반 질문 강화
            prompt = f"""
            다음은 자소서 기반으로 생성된 면접 질문 목록입니다:
            {json.dumps(questions, ensure_ascii=False, indent=2)}
            
            다음은 관련 CS 지식 참고 자료입니다:
            {cs_context}
            
            위 질문 목록 중 1-2개를 CS 참고 자료의 내용을 반영하여 더 심층적이고 기술적인 질문으로 발전시켜주세요.
            질문의 형식은 기존 질문과 동일하게 유지하되, 내용만 CS 지식을 반영하여 더 전문적으로 만들어주세요.
            
            응답은 반드시 유효한 JSON 형식의 질문 리스트로 제공해주세요.
            """
            
            # API 요청 데이터
            data = {
                "model": "gpt-4o",
                "messages": [
                    {"role": "system", "content": "당신은 CS 전문 기술 면접관입니다."},
                    {"role": "user", "content": prompt}
                ],
                "temperature": 0.7
            }
            
            # OpenAI API 호출
            response = requests.post(self.api_endpoint, headers=self.api_headers, json=data)
            response.raise_for_status()
            
            response_data = response.json()
            content = response_data['choices'][0]['message']['content']
            
            # JSON 파싱
            if '```json' in content:
                json_content = content.split('```json')[1].split('```')[0].strip()
                enhanced_questions = json.loads(json_content)
            elif '```' in content:
                json_content = content.split('```')[1].split('```')[0].strip()
                enhanced_questions = json.loads(json_content)
            else:
                enhanced_questions = json.loads(content)
            
            # 기존 질문 중 일부를 강화된 질문으로 교체
            num_to_replace = min(len(enhanced_questions), 2)  # 최대 2개 질문 교체
            for i in range(num_to_replace):
                if i < len(questions):
                    questions[i] = enhanced_questions[i]
            
            logger.info(f"{num_to_replace}개 질문이 CS 지식으로 강화되었습니다.")
            return questions
            
        except Exception as e:
            logger.error(f"CS 지식 강화 오류: {e}")
            return questions  # 오류 발생 시 원래 질문 반환

    def _extract_tech_keywords(self, text):
        """텍스트에서 기술 관련 키워드 추출"""
        # 기술 키워드 목록
        tech_keywords = [
            "알고리즘", "자료구조", "데이터베이스", "네트워크", "운영체제",
            "프로그래밍", "코딩", "개발", "소프트웨어", "백엔드", "프론트엔드",
            "API", "서버", "Java", "Python", "JavaScript", "C++", "SQL",
            "클라우드", "시스템", "아키텍처", "보안", "애자일", "테스트",
            "웹", "앱", "모바일", "인공지능", "머신러닝", "데이터"
        ]
        
        # 키워드 매칭
        found_keywords = []
        text_lower = text.lower()
        
        for keyword in tech_keywords:
            if keyword.lower() in text_lower:
                found_keywords.append(keyword)
        
        return found_keywords
