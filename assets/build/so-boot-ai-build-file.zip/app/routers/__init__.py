"""
라우터 모듈 초기화

API 라우터를 등록하고 관리하는 모듈
"""

from fastapi import APIRouter

from .questions import router as questions_router
from .rehearsals import router as rehearsals_router

# 모든 라우터 리스트
routers = [
    questions_router,
    rehearsals_router,
]
