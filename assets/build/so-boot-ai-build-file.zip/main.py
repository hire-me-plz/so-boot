"""
자소서 기반 면접 질문 생성 API 서비스

FastAPI 애플리케이션의 진입점
"""

import uvicorn
import os
from dotenv import load_dotenv
from app.main import app

# 환경 변수 로드
load_dotenv()

if __name__ == "__main__":
    # 서버 호스트 및 포트 설정
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", "8000"))
    
    # 서버 실행
    uvicorn.run("app.main:app", host=host, port=port, reload=True)
