"""
FastAPI 애플리케이션 메인 모듈

자소서 기반 면접 질문 생성 API 서비스의 메인 진입점
"""

import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import os
from dotenv import load_dotenv

from .routers import routers
from .services.vector_store import VectorStoreService

# 환경 변수 로드
load_dotenv()

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

# FastAPI 앱 생성 함수
def create_app() -> FastAPI:
    """
    FastAPI 앱 생성 및 설정
    
    Returns:
        설정이 완료된 FastAPI 앱
    """
    # 앱 생성
    app = FastAPI(
        title="자소서 기반 면접 질문 생성 API",
        description="자소서 데이터를 분석하여 맞춤형 면접 질문을 생성하는 API 서비스",
        version="1.0.0",
        docs_url="/fastapi/docs",
        redoc_url="/fastapi/redoc",
        openapi_url="/fastapi/openapi.json",
    )
    
    # CORS 설정
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # 프로덕션에서는 특정 도메인으로 제한
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # 라우터 등록
    for router in routers:
        app.include_router(router)
    
    # 시작 이벤트 핸들러 등록
    @app.on_event("startup")
    async def startup_event():
        """앱 시작 시 실행될 이벤트 핸들러"""
        try:
            # 벡터 저장소 초기화
            vector_store = VectorStoreService()
            await vector_store.initialize_collection()
            logger.info("벡터 저장소가 초기화되었습니다.")
        except Exception as e:
            logger.error(f"벡터 저장소 초기화 오류: {e}")
    
    # 전역 예외 핸들러 등록
    @app.exception_handler(Exception)
    async def global_exception_handler(request, exc):
        """전역 예외 핸들러"""
        logger.error(f"예외 발생: {exc}")
        return JSONResponse(
            status_code=500,
            content={"detail": f"내부 서버 오류: {str(exc)}"}
        )
    
    # 루트 엔드포인트 등록
    @app.get("/fastapi")
    async def root():
        """루트 엔드포인트"""
        return {
            "message": "자소서 기반 면접 질문 생성 API에 오신 것을 환영합니다.",
            "docs_url": "/fastapi/docs",
            "redoc_url": "/fastapi/redoc"
        }
    
    return app

# FastAPI 앱 인스턴스 생성
app = create_app()
