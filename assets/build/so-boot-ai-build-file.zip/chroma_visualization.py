import os
import json
import time
import requests
import chromadb
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import plotly.express as px
import plotly.graph_objects as go
from dotenv import load_dotenv
from chromadb.utils import embedding_functions

# 환경 변수 로드
load_dotenv()

# ChromaDB 접속 정보
CHROMA_HOST = os.getenv("CHROMA_HOST", "localhost")
CHROMA_PORT = int(os.getenv("CHROMA_PORT", "8001"))
COLLECTION_NAME = "resume_embeddings"  # 컬렉션 이름

# GMS를 통해 OpenAI API를 호출하는 임베딩 함수 클래스
class GMSOpenAIEmbeddingFunction(embedding_functions.EmbeddingFunction):
  """GMS를 통해 OpenAI API를 호출하는 임베딩 함수"""

  def __init__(self, api_key: str, model_name: str = "text-embedding-3-small", dimensions: int = 1536):
    """
    GMS OpenAI 임베딩 함수 초기화

    Args:
        api_key: OpenAI API 키
        model_name: 임베딩 모델 이름
        dimensions: 임베딩 차원
    """
    self.api_key = api_key
    self.model_name = model_name
    self.dimensions = dimensions
    # GMS 프록시 URL 설정
    self.api_url = "https://gms.p.ssafy.io/gmsapi/api.openai.com/v1/embeddings"
    self.headers = {
      "Content-Type": "application/json",
      "Authorization": f"Bearer {api_key}"
    }
    print(f"GMS OpenAI 임베딩 함수 초기화: {model_name}, 차원: {dimensions}")

  def __call__(self, texts):
    """
    텍스트 목록에 대한 임베딩 생성

    Args:
        texts: 임베딩할 텍스트 목록

    Returns:
        생성된 임베딩 목록
    """
    embeddings = []

    for i, text in enumerate(texts):
      try:
        # API 요청 데이터 구성
        payload = {
          "model": self.model_name,
          "input": text,
          "dimensions": self.dimensions
        }

        # GMS를 통한 OpenAI API 호출
        response = requests.post(
            self.api_url,
            headers=self.headers,
            json=payload,
            timeout=30
        )

        # 응답 확인
        if response.status_code == 200:
          result = response.json()
          embedding = result["data"][0]["embedding"]
          embeddings.append(embedding)
          print(f"임베딩 {i+1}/{len(texts)} 생성 완료")
        else:
          error_msg = f"임베딩 API 오류: {response.status_code} - {response.text}"
          print(error_msg)
          raise Exception(error_msg)

        # 연속 호출 사이에 짧은 지연 추가 (API 호출 제한 방지)
        if i < len(texts) - 1:
          time.sleep(0.5)

      except Exception as e:
        print(f"임베딩 생성 중 오류: {str(e)}")
        # 오류 발생 시 영벡터 반환 (임시 방편, 나중에 더 나은 오류 처리 구현 필요)
        embeddings.append([0.0] * self.dimensions)

    return embeddings

def connect_to_chroma():
  """ChromaDB에 연결"""
  try:
    # OpenAI API 키 가져오기
    openai_api_key = os.getenv("OPENAI_API_KEY")
    if not openai_api_key:
      print("OpenAI API 키가 설정되지 않았습니다.")
      return None

    # 클라이언트 초기화
    client = chromadb.HttpClient(host=CHROMA_HOST, port=CHROMA_PORT)
    print(f"ChromaDB 서버에 연결 성공: {CHROMA_HOST}:{CHROMA_PORT}")

    return client
  except Exception as e:
    print(f"ChromaDB 연결 오류: {e}")
    return None

def get_collection_data(client, collection_name):
  """컬렉션 데이터 가져오기"""
  try:
    # OpenAI API 키 가져오기
    openai_api_key = os.getenv("OPENAI_API_KEY")
    if not openai_api_key:
      print("OpenAI API 키가 설정되지 않았습니다.")
      return None

    # 커스텀 임베딩 함수 초기화 (vector_store.py와 동일하게)
    embedding_function = GMSOpenAIEmbeddingFunction(
        api_key=openai_api_key,
        model_name="text-embedding-3-small",
        dimensions=1536
    )

    # 임베딩 함수를 지정하여 컬렉션 가져오기
    collection = client.get_collection(
        name=collection_name,
        embedding_function=embedding_function
    )

    print(f"컬렉션 '{collection_name}' 가져오기 성공")

    # 컬렉션에 있는 문서 수 가져오기
    collection_count = collection.count()
    print(f"컬렉션에 {collection_count}개 문서가 있습니다.")

    if collection_count == 0:
      print("컬렉션에 문서가 없습니다.")
      return None

    # 모든 데이터 가져오기
    result = collection.get(include=["embeddings", "documents", "metadatas"])

    # 필수 키 확인
    for key in ["ids", "embeddings", "documents", "metadatas"]:
      if key not in result:
        print(f"'{key}' 데이터가 없습니다.")
        return None

      if key == "embeddings":
        if not isinstance(result[key], list) or len(result[key]) == 0:
          print("임베딩 데이터가 비어 있거나 올바른 형식이 아닙니다.")
          if "documents" in result and isinstance(result["documents"], list) and len(result["documents"]) > 0:
            print("문서 데이터는 있습니다. 직접 임베딩을 생성합니다.")
            # 임베딩 생성
            docs_embeddings = embedding_function(result["documents"])
            result["embeddings"] = docs_embeddings
            print(f"{len(docs_embeddings)}개 임베딩 생성 완료")
          else:
            return None
      else:
        if not isinstance(result[key], list) or len(result[key]) == 0:
          print(f"'{key}' 데이터가 비어 있습니다.")
          return None

    print(f"총 {len(result['ids'])}개 문서 로드 완료")
    if result["embeddings"] and len(result["embeddings"]) > 0:
      print(f"임베딩 샘플 (첫 번째 문서): {result['embeddings'][0][:5]}...")

    return result

  except Exception as e:
    print(f"컬렉션 데이터 로드 오류: {e}")
    return None

def create_2d_visualization(embeddings, metadatas, output_path="chroma_2d_viz.png", color_by="type"):
  """2D PCA 시각화 생성"""
  if not embeddings or len(embeddings) == 0:
    print("시각화할 임베딩 데이터가 없습니다.")
    return None

  # 임베딩 데이터가 numpy 배열인지 확인
  embeddings_array = np.array(embeddings)
  print(f"임베딩 배열 형태: {embeddings_array.shape}")

  if embeddings_array.ndim != 2:
    print(f"임베딩 데이터 형태가 잘못되었습니다. 현재 형태: {embeddings_array.shape}")
    return None

  # PCA로 차원 축소 (1536차원 -> 2차원)
  pca = PCA(n_components=2)
  embeddings_2d = pca.fit_transform(embeddings_array)

  # 데이터프레임 생성
  df = pd.DataFrame(embeddings_2d, columns=["x", "y"])

  # 메타데이터 추가
  for i, metadata in enumerate(metadatas):
    for key, value in metadata.items():
      df.loc[i, key] = str(value)  # 모든 값을 문자열로 변환

  # 시각화
  plt.figure(figsize=(14, 10))

  if color_by in df.columns:
    scatter = sns.scatterplot(
        data=df,
        x="x",
        y="y",
        hue=color_by,
        palette="viridis",
        s=100,
        alpha=0.7
    )
    # 범례 위치 조정
    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
  else:
    scatter = sns.scatterplot(
        data=df,
        x="x",
        y="y",
        palette="viridis",
        s=100,
        alpha=0.7
    )

  # 제목 및 축 레이블
  plt.title(f"ChromaDB 임베딩 2D 시각화 (PCA) - 색상: {color_by}", fontsize=16)
  plt.xlabel("주성분 1", fontsize=12)
  plt.ylabel("주성분 2", fontsize=12)
  plt.tight_layout()

  # 저장 및 표시
  plt.savefig(output_path)
  print(f"2D 시각화 이미지 저장 완료: {output_path}")
  plt.close()  # 메모리 관리를 위해 닫기

  return df

def create_3d_visualization(embeddings, metadatas, documents, ids, output_path="chroma_3d_viz.html", color_by="type"):
  """3D 시각화 생성 (Plotly 사용)"""
  if not embeddings or len(embeddings) == 0:
    print("시각화할 임베딩 데이터가 없습니다.")
    return None

  # 임베딩 데이터가 numpy 배열인지 확인
  embeddings_array = np.array(embeddings)

  if embeddings_array.ndim != 2:
    print(f"임베딩 데이터 형태가 잘못되었습니다. 현재 형태: {embeddings_array.shape}")
    return None

  # PCA로 차원 축소 (1536차원 -> 3차원)
  pca = PCA(n_components=3)
  embeddings_3d = pca.fit_transform(embeddings_array)

  # 데이터프레임 생성
  df = pd.DataFrame(embeddings_3d, columns=["x", "y", "z"])
  df["id"] = ids
  df["document_preview"] = [doc[:100] + "..." if len(doc) > 100 else doc for doc in documents]

  # 메타데이터 추가
  for i, metadata in enumerate(metadatas):
    for key, value in metadata.items():
      df.loc[i, key] = str(value)  # 모든 값을 문자열로 변환

  # 대표적인 메타데이터 필드만 선택
  hover_data = ["id", "document_preview"]
  for key in metadatas[0].keys():
    if key not in [color_by]:  # 이미 색상으로 사용 중인 필드는 제외
      hover_data.append(key)

  # 3D 산점도 생성
  fig = px.scatter_3d(
      df,
      x="x",
      y="y",
      z="z",
      color=color_by,
      hover_name="id",
      hover_data=hover_data,
      title=f"ChromaDB 임베딩 3D 시각화 (PCA) - 색상: {color_by}"
  )

  # 마커 크기 및 불투명도 조정
  fig.update_traces(marker=dict(size=5), selector=dict(mode='markers'))

  # 레이아웃 조정
  fig.update_layout(
      scene=dict(
          xaxis_title="주성분 1",
          yaxis_title="주성분 2",
          zaxis_title="주성분 3"
      ),
      width=1000,
      height=800,
      margin=dict(l=0, r=0, b=0, t=30)
  )

  # HTML 파일로 저장
  fig.write_html(output_path)
  print(f"3D 시각화 HTML 저장 완료: {output_path}")

  return df

def create_tsne_visualization(embeddings, metadatas, output_path="chroma_tsne_viz.png", color_by="type"):
  """t-SNE 시각화 생성 (더 나은 클러스터링을 위해)"""
  if not embeddings or len(embeddings) == 0:
    print("시각화할 임베딩 데이터가 없습니다.")
    return None

  # 임베딩 데이터가 numpy 배열인지 확인
  embeddings_array = np.array(embeddings)

  if embeddings_array.ndim != 2:
    print(f"임베딩 데이터 형태가 잘못되었습니다. 현재 형태: {embeddings_array.shape}")
    return None

  # 데이터 수에 따라 perplexity 조정
  perplexity = min(30, len(embeddings) - 1)
  if perplexity < 5:
    perplexity = 5

  # t-SNE로 차원 축소 (1536차원 -> 2차원)
  tsne = TSNE(n_components=2, perplexity=perplexity, n_iter=1000, random_state=42)
  embeddings_tsne = tsne.fit_transform(embeddings_array)

  # 데이터프레임 생성
  df = pd.DataFrame(embeddings_tsne, columns=["x", "y"])

  # 메타데이터 추가
  for i, metadata in enumerate(metadatas):
    for key, value in metadata.items():
      df.loc[i, key] = str(value)  # 모든 값을 문자열로 변환

  # 시각화
  plt.figure(figsize=(14, 10))

  if color_by in df.columns:
    scatter = sns.scatterplot(
        data=df,
        x="x",
        y="y",
        hue=color_by,
        palette="viridis",
        s=100,
        alpha=0.7
    )
    # 범례 위치 조정
    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
  else:
    scatter = sns.scatterplot(
        data=df,
        x="x",
        y="y",
        palette="viridis",
        s=100,
        alpha=0.7
    )

  # 제목 및 축 레이블
  plt.title(f"ChromaDB 임베딩 t-SNE 시각화 - 색상: {color_by}", fontsize=16)
  plt.xlabel("t-SNE 1", fontsize=12)
  plt.ylabel("t-SNE 2", fontsize=12)
  plt.tight_layout()

  # 저장 및 표시
  plt.savefig(output_path)
  print(f"t-SNE 시각화 이미지 저장 완료: {output_path}")
  plt.close()  # 메모리 관리를 위해 닫기

  return df

def visualize_chroma():
  """ChromaDB 시각화 메인 함수"""
  # ChromaDB 연결
  client = connect_to_chroma()
  if not client:
    return

  # 컬렉션 데이터 가져오기
  result = get_collection_data(client, COLLECTION_NAME)
  if not result:
    return

  # 임베딩 및 메타데이터 추출
  embeddings = result["embeddings"]
  metadatas = result["metadatas"]
  documents = result["documents"]
  ids = result["ids"]

  # 임베딩 확인
  if not embeddings or len(embeddings) == 0:
    print("임베딩 데이터가 없습니다.")
    return

  embeddings_array = np.array(embeddings)
  print(f"임베딩 차원: {embeddings_array.shape}")

  # 메타데이터 필드 확인
  metadata_fields = set()
  for m in metadatas:
    metadata_fields.update(m.keys())
  print(f"메타데이터 필드: {', '.join(metadata_fields)}")

  # 시각화 색상 필드 설정 (기본값: type)
  color_field = "type"  # 또는 "resume_id", "member_id", "position", "company_name" 등

  # 2D PCA 시각화 생성
  print("\n2D PCA 시각화 생성 중...")
  df_2d = create_2d_visualization(embeddings, metadatas, color_by=color_field)

  # 3D PCA 시각화 생성
  print("\n3D PCA 시각화 생성 중...")
  df_3d = create_3d_visualization(embeddings, metadatas, documents, ids, color_by=color_field)

  # t-SNE 시각화 생성 (선택적)
  print("\nt-SNE 시각화 생성 중...")
  df_tsne = create_tsne_visualization(embeddings, metadatas, color_by=color_field)

  print("\n시각화 완료!")

  # 결과 요약
  unique_values = {}
  for field in ["type", "resume_id", "member_id", "position", "company_name"]:
    if df_2d is not None and field in df_2d.columns:
      unique_values[field] = df_2d[field].unique().tolist()
      print(f"{field} 고유값 ({len(unique_values[field])}개): {unique_values[field][:5]}{'...' if len(unique_values[field]) > 5 else ''}")

if __name__ == "__main__":
  visualize_chroma()