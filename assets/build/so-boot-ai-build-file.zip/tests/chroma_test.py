import os
import logging
import sys
import requests
import time
import json
from dotenv import load_dotenv
import chromadb

# ChromaDB 버전 로깅
logging.info(f"ChromaDB 클라이언트 버전: {chromadb.__version__}")

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format='%(levelname)s: %(message)s',  # 간결한 형식으로 변경
    handlers=[
        logging.FileHandler("chroma_test.log"),
        logging.StreamHandler(sys.stdout)
    ]
)

# 환경 변수 로드
load_dotenv()

def check_chroma_server(host="localhost", port=8000, max_retries=5):
    """ChromaDB 서버 연결 확인"""
    import requests
    
    logging.info(f"ChromaDB 서버 연결 확인 중 ({host}:{port})...")
    
    # 여러 가능한 엔드포인트 시도
    endpoints = [
        "/api/v1/heartbeat",  # 이전 버전
        "/heartbeat",         # 최신 버전
        "/api/v1",            # 기본 API
        "/"                   # 루트
    ]
    
    for i in range(max_retries):
        for endpoint in endpoints:
            try:
                url = f"http://{host}:{port}{endpoint}"
                logging.info(f"엔드포인트 시도: {url}")
                response = requests.get(url)
                
                if response.status_code == 200:
                    logging.info(f"ChromaDB 서버 연결 성공! 엔드포인트: {endpoint}, 응답: {response.text}")
                    return True
                else:
                    logging.warning(f"ChromaDB 서버 응답 오류: {response.status_code} - 엔드포인트: {endpoint}")
            except Exception as e:
                logging.warning(f"ChromaDB 서버 연결 시도 실패 (엔드포인트: {endpoint}): {e}")
        
        # 재시도 전 대기
        if i < max_retries - 1:
            wait_time = 2 ** i  # 지수 백오프
            logging.info(f"{wait_time}초 후 재시도합니다...")
            time.sleep(wait_time)
    
    logging.error(f"ChromaDB 서버 연결 실패 ({max_retries}회 시도)")
    return False

def test_openai_embedding():
    """OpenAI API 임베딩 테스트"""
    # API 키 가져오기
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        logging.error("오류: OPENAI_API_KEY 환경 변수가 설정되지 않았습니다.")
        print("   오류: OPENAI_API_KEY 환경 변수가 설정되지 않았습니다.")
        return None
    
    # 임베딩 생성
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }
    payload = {
        "input": "테스트 문서입니다.",
        "model": "text-embedding-3-small",
        "dimensions": 384  # 차원 수를 384로 지정
    }
    
    try:
        logging.info("OpenAI API 임베딩 요청 중...")
        print("   OpenAI API에 임베딩 요청 중...")
        response = requests.post(
            "https://api.openai.com/v1/embeddings",
            headers=headers,
            json=payload,
            timeout=30
        )
        
        if response.status_code == 200:
            result = response.json()
            embedding = result["data"][0]["embedding"]
            logging.info(f"임베딩 생성 성공: 차원 = {len(embedding)}")
            print(f"   임베딩 생성 성공! 차원 = {len(embedding)}")
            # 임베딩 형식 확인
            logging.info(f"임베딩 타입: {type(embedding)}")
            logging.info(f"임베딩 첫 5개 값: {embedding[:5]}")
            return embedding
        else:
            logging.error(f"임베딩 생성 실패: {response.status_code} - {response.text}")
            print(f"   오류: 임베딩 생성 실패 (상태 코드: {response.status_code})")
            return None
    except Exception as e:
        logging.error(f"임베딩 요청 중 오류: {e}")
        print(f"   오류: 임베딩 요청 중 예외 발생 - {e}")
        return None

def test_chroma_http_client():
    """ChromaDB HTTP 클라이언트 테스트"""
    try:
        logging.info("ChromaDB HTTP 클라이언트 테스트 시작...")
        print("   ChromaDB HTTP 클라이언트 생성 중...")
        
        # HTTP 클라이언트 생성 (Docker에서 실행 중인 ChromaDB 서버에 연결)
        client = chromadb.HttpClient(host="localhost", port=8000)
        logging.info("ChromaDB HTTP 클라이언트 생성 성공")
        print("   ChromaDB HTTP 클라이언트 생성 성공!")
        
        # 서버 정보 요청 (클라이언트가 자동으로 연결 확인)
        try:
            logging.info("직접 HTTP 요청으로 서버 상태 확인...")
            print("   서버 상태 확인 중...")
            import requests
            for path in ['/', '/api/v1', '/api/v1/collections']:
                try:
                    resp = requests.get(f'http://localhost:8000{path}')
                    logging.info(f"엔드포인트 {path} 응답: {resp.status_code}")
                except Exception as e:
                    logging.warning(f"엔드포인트 {path} 요청 실패: {e}")
        except Exception as e:
            logging.warning(f"서버 상태 확인 중 오류: {e}")
        
        # 컬렉션 생성
        try:
            print("   기존 테스트 컬렉션 삭제 시도...")
            client.delete_collection("test_collection")
            logging.info("기존 테스트 컬렉션 삭제 완료")
            print("   기존 테스트 컬렉션 삭제 완료")
        except Exception as e:
            logging.info(f"기존 테스트 컬렉션이 없습니다: {e}")
            print("   기존 테스트 컬렉션이 없거나 삭제할 수 없습니다")
        
        print("   새 테스트 컬렉션 생성 중...")
        collection = client.create_collection("test_collection")
        logging.info("테스트 컬렉션 생성 성공")
        print("   테스트 컬렉션 생성 성공!")
        
        # 기본 데이터 추가 (임베딩 자동 생성)
        print("   기본 테스트 데이터 추가 중...")
        collection.add(
            ids=["test1", "test2"],
            documents=["This is a test", "Another test document"],
            metadatas=[{"source": "test1"}, {"source": "test2"}]
        )
        logging.info("기본 데이터 추가 성공")
        print("   기본 테스트 데이터 추가 성공!")
        
        # 컬렉션 정보 확인
        count = collection.count()
        logging.info(f"컬렉션의 문서 수: {count}")
        print(f"   현재 컬렉션의 문서 수: {count}")
        
        return collection
    except Exception as e:
        logging.error(f"ChromaDB HTTP 클라이언트 테스트 중 오류: {e}")
        print(f"   오류: ChromaDB HTTP 클라이언트 테스트 중 예외 발생 - {e}")
        import traceback
        logging.error(traceback.format_exc())
        return None

def test_chroma_with_embedding(collection, embedding):
    """ChromaDB에 임베딩 추가 테스트"""
    if not collection or not embedding:
        logging.error("컬렉션 또는 임베딩이 없습니다.")
        print("   오류: 컬렉션 또는 임베딩이 없습니다.")
        return False
    
    try:
        logging.info("임베딩과 함께 데이터 추가 테스트...")
        print(f"   임베딩 차원 확인: {len(embedding)}")
        
        # 데이터 추가 시도
        print("   컬렉션에 임베딩을 포함한 문서 추가 중...")
        collection.add(
            ids=["test_embed"],
            documents=["임베딩이 포함된 테스트 문서입니다."],
            embeddings=[embedding],
            metadatas=[{"source": "embed_test"}]
        )
        
        logging.info("임베딩과 함께 데이터 추가 성공")
        print("   성공: 임베딩과 함께 데이터 추가됨")
        
        # 컬렉션 정보 확인
        count = collection.count()
        logging.info(f"컬렉션의 문서 수: {count}")
        print(f"   현재 컬렉션의 문서 수: {count}")
        
        # 쿼리 테스트
        print("   임베딩을 사용하여 컬렉션 쿼리 테스트 중...")
        results = collection.query(
            query_embeddings=[embedding],
            n_results=2
        )
        
        if results and 'documents' in results and results['documents']:
            print(f"   성공: 쿼리 결과 - {len(results['documents'][0])} 문서 검색됨")
            if results['documents'][0]:
                print(f"   찾은 문서: {results['documents'][0][0]}")
                if 'metadatas' in results and results['metadatas'][0]:
                    print(f"   메타데이터: {results['metadatas'][0][0]}")
        
        logging.info(f"쿼리 테스트 성공")
        
        return True
    except Exception as e:
        logging.error(f"임베딩 추가 테스트 중 오류: {e}")
        print(f"   오류 발생: {e}")
        import traceback
        logging.error(traceback.format_exc())
        return False

def main():
    print("\n====== ChromaDB Docker 서버 테스트 시작 ======\n")
    logging.info("ChromaDB Docker 서버 테스트 시작")
    
    # 서버 연결 확인 건너뛰기
    # 엔드포인트 확인은 생략하고 직접 클라이언트 연결 시도
    print("\n1. ChromaDB 서버에 직접 연결 시도...")
    logging.info("ChromaDB 서버 연결 확인 단계를 건너뛰고 직접 연결을 시도합니다.")
    
    # OpenAI 임베딩 테스트
    print("\n2. OpenAI 임베딩 생성 테스트 (384 차원)...")
    embedding = test_openai_embedding()
    if embedding:
        print(f"   임베딩 생성 성공! 차원: {len(embedding)}")
    
    # ChromaDB HTTP 클라이언트 테스트
    print("\n3. ChromaDB HTTP 클라이언트 테스트...")
    collection = test_chroma_http_client()
    if collection:
        print(f"   컬렉션 생성 성공! 이름: {collection.name}")
    
    # 임베딩과 함께 ChromaDB 테스트
    if embedding and collection:
        print("\n4. 임베딩을 컬렉션에 추가하는 테스트...")
        success = test_chroma_with_embedding(collection, embedding)
        if success:
            print("\n====== 결과: 모든 테스트 성공! ======")
            logging.info("모든 테스트 성공!")
        else:
            print("\n====== 결과: 임베딩 추가 테스트 실패 ======")
            logging.error("임베딩 추가 테스트 실패!")
    else:
        print("\n====== 결과: 필수 테스트 실패 ======")
        logging.error("필수 테스트가 실패하여 진행할 수 없습니다.")
    
    print("\n====== ChromaDB 테스트 종료 ======\n")
    logging.info("ChromaDB 테스트 종료")

if __name__ == "__main__":
    main()
