"""
자소서 기반 면접 질문 생성 API 라우터
CSV 파일에서 CS 지식 데이터 로드 기능 포함
"""

from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, Form
from typing import List, Dict, Any, Optional
from fastapi.responses import JSONResponse
import logging

from ..services.rag_service import RAGService
from ..services.vector_store import VectorStoreService
from ..models.schemas import (
    InterviewQuestionRequest, 
    InterviewQuestionResponse, 
    GeneratedQuestion,
    SaveResult,
    BaseResponse
)

# 로깅 설정
logger = logging.getLogger(__name__)

# 라우터 생성
router = APIRouter(
    prefix="/fastapi/questions",
    tags=["questions"],
    responses={
        404: {"description": "Not found"},
        500: {"description": "Internal server error"}
    },
)

# 서비스 인스턴스
vector_store_service = None
rag_service = None

# 의존성 주입: 벡터 저장소 서비스 제공
async def get_vector_store_service():
    global vector_store_service
    if vector_store_service is None:
        vector_store_service = VectorStoreService()
        await vector_store_service.initialize_collection()
    return vector_store_service

# 의존성 주입: RAG 서비스 제공
async def get_rag_service(vector_store: VectorStoreService = Depends(get_vector_store_service)):
    global rag_service
    if rag_service is None:
        rag_service = RAGService(vector_store)
    return rag_service

# API 엔드포인트: 자소서 데이터 로드
@router.post("/load-resume", response_model=SaveResult)
async def load_resume_data(
    resume_id: Optional[int] = None,
    background_tasks: BackgroundTasks = None,
    rag: RAGService = Depends(get_rag_service)
):
    """
    자소서 데이터를 DB에서 불러와 벡터 저장소에 저장
    
    Args:
        resume_id: 자소서 ID (None인 경우 모든 자소서 처리)
        background_tasks: 백그라운드 태스크
        
    Returns:
        처리 결과
    """
    try:
        # 백그라운드 태스크가 있는 경우 백그라운드로 처리
        if background_tasks:
            # 백그라운드 태스크로 처리
            background_tasks.add_task(rag.fetch_and_process_resume_data, resume_id)
            return SaveResult(
                success=True, 
                message=f"자소서 ID {resume_id or '전체'}의 처리가 백그라운드에서 진행 중입니다."
            )
        
        # 동기적으로 처리
        doc_count = await rag.fetch_and_process_resume_data(resume_id)
        
        if doc_count == 0:
            return SaveResult(
                success=False, 
                message=f"자소서 ID {resume_id or '전체'}에 대한 데이터를 찾을 수 없습니다."
            )
        
        return SaveResult(
            success=True, 
            message=f"{doc_count}개 문서가 벡터 저장소에 저장되었습니다."
        )
    
    except Exception as e:
        logger.error(f"자소서 데이터 로드 오류: {str(e)}")
        raise HTTPException(status_code=500, detail=f"자소서 데이터 로드 중 오류 발생: {str(e)}")

# API 엔드포인트: 면접 질문 생성 (수정 버전)
@router.post("/cover-letter")  # response_model 제거
async def generate_questions_from_cover_letter(
    request: InterviewQuestionRequest,
    rag: RAGService = Depends(get_rag_service)
):
    """
    자소서 기반 면접 질문 생성

    Args:
        request: 질문 생성 요청

    Returns:
        생성된 면접 질문을 래핑한 API 응답
    """
    try:
        # 면접 질문 생성
        questions, saved_ids = await rag.generate_interview_questions(
            resume_id=request.resume_id,
            member_id=request.member_id,
            position=request.position,
            num_questions=request.num_questions,
            save_to_db=True
        )

        if not questions:
            return JSONResponse(
                status_code=404,
                content={
                    "isSuccess": False,
                    "code": 404,
                    "message": f"자소서 ID {request.resume_id}에 대한 질문 생성에 실패했습니다.",
                    "result": None
                }
            )

        # 응답 구성
        response_data = InterviewQuestionResponse(
            resume_id=request.resume_id,
            job_role=request.position or "미지정 직무",
            experience_level=0,  # 기본값 설정
            questions=[
                GeneratedQuestion(
                    question_text=q["question_text"],
                    evaluation_points=q["evaluation_points"],
                    key_answer_points=q["key_answer_points"]
                )
                for q in questions
            ]
        )

        # 래핑된 응답 반환
        wrapped_response = {
            "isSuccess": True,
            "code": 200,
            "message": "요청에 성공하였습니다.",
            "result": response_data.dict()
        }

        return JSONResponse(content=wrapped_response)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"면접 질문 생성 오류: {str(e)}")
        return JSONResponse(
            status_code=500,
            content={
                "isSuccess": False,
                "code": 500,
                "message": f"면접 질문 생성 중 오류 발생: {str(e)}",
                "result": None
            }
        )

# API 엔드포인트: CSV에서 CS 데이터 로드
@router.post("/load-cs-data")
async def load_cs_data(
    file_path: str = Form(...),
    background_tasks: BackgroundTasks = None,
    vector_store: VectorStoreService = Depends(get_vector_store_service)
):
    """
    CSV 파일에서 CS 데이터 로드 API
    
    Args:
        file_path: CSV 파일 경로
        background_tasks: 백그라운드 태스크
        
    Returns:
        처리 결과
    """
    try:
        # 데이터 로더 모듈 임포트
        from ..services.data_loader import load_cs_data_from_csv
        
        if background_tasks:
            # 백그라운드 태스크로 처리
            background_tasks.add_task(load_cs_data_from_csv, file_path, vector_store)
            return {
                "success": True, 
                "message": f"CS 데이터 로드가 백그라운드에서 진행 중입니다."
            }
        
        # 동기적으로 처리
        doc_count = await load_cs_data_from_csv(file_path, vector_store)
        
        if doc_count == 0:
            return {
                "success": False, 
                "message": "CS 데이터 로드 실패"
            }
        
        return {
            "success": True, 
            "message": f"{doc_count}개 CS 문서가 벡터 저장소에 저장되었습니다."
        }
    
    except Exception as e:
        logger.error(f"CS 데이터 로드 오류: {str(e)}")
        raise HTTPException(status_code=500, detail=f"CS 데이터 로드 오류: {str(e)}")


