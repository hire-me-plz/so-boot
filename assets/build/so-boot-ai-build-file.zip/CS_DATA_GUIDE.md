# CS 지식 데이터 로드 및 활용 가이드

이 가이드는 so-boot-ai 프로젝트에 CS 지식 데이터를 추가하고 자소서 기반 면접 질문 생성에 활용하는 방법을 설명합니다.

## 1. 개요

CS 지식 데이터를 ChromaDB에 저장하여 자소서 기반 면접 질문 생성 시 참조할 수 있습니다. 이를 통해 더 심층적이고 기술적인 면접 질문을 생성할 수 있습니다.

## 2. CSV 파일 형식

CS 지식 데이터는 다음 5개 열을 포함하는 CSV 파일로 준비합니다:

```
id,title,content,category,keywords
```

- **id**: 고유 식별자 (예: "CS001")
- **title**: 주제 제목 (예: "이진 탐색 알고리즘")
- **content**: 주요 내용 (전체 설명 텍스트)
- **category**: 대분류 (예: "알고리즘", "자료구조", "네트워크")
- **keywords**: 관련 키워드 (쉼표로 구분, 예: "이진 탐색,정렬,시간 복잡도")

## 3. CS 데이터 로드 방법

### 3.1 CLI 스크립트 사용

프로젝트 루트 디렉토리에서 다음 명령어를 실행합니다:

```bash
python load_cs_data.py --csv="cs_knowledge.csv"
```

### 3.2 API 엔드포인트 사용

다음 API 엔드포인트로 POST 요청을 보냅니다:

```
POST /fastapi/questions/load-cs-data
Content-Type: application/x-www-form-urlencoded

file_path=C:/path/to/cs_knowledge.csv
```

## 4. 면접 질문 생성 방법

기존 자소서 기반 면접 질문 생성 API를 사용합니다:

```
POST /fastapi/questions/cover-letter
Content-Type: application/json

{
  "resume_id": 1,
  "member_id": 1,
  "position": "백엔드 개발자",
  "num_questions": 5
}
```

이제 생성된 질문 중 일부는 CS 지식을 활용한 더 심층적인 기술 질문으로 강화됩니다.

## 5. 작동 방식

1. 시스템은 자소서 내용에서 기술 키워드를 추출합니다.
2. 추출된 키워드를 사용하여 관련 CS 지식을 검색합니다.
3. 검색된 CS 지식을 참조하여 원래 생성된 질문 중 일부를 더 기술적이고 심층적인 질문으로 강화합니다.

## 6. CSV 샘플 파일

프로젝트 루트 디렉토리에 `cs_knowledge.csv` 샘플 파일이 포함되어 있습니다. 이 파일은 10개의 기본 CS 주제를 담고 있으며, 필요에 따라 더 많은 항목을 추가할 수 있습니다.

## 7. 주의사항

- CSV 파일은 UTF-8 인코딩으로 저장해야 합니다.
- 콘텐츠 열에 쉼표가 포함된 경우, CSV 파서가 올바르게 처리할 수 있도록 해당 필드를 따옴표로 묶어야 합니다.
- 대용량 데이터를 로드할 경우 백그라운드 태스크를 사용하는 것이 좋습니다.
